package com.tunes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Size
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.collect.ImmutableList

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastFactory: MediaNotification.ActionFactory? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var nm: NotificationManager
    private lateinit var am: AudioManager

    // cached art for the current track
    private var cacheId: String? = null
    private var cover: Bitmap? = null
    private var bg: Bitmap? = null

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            if (session?.player?.isPlaying == true) handler.postDelayed(this, 1000)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, k -> if (k == "fav") refresh() }

    private val actions = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val p = session?.player ?: return
            when (i.action) {
                ACT_FAV -> {
                    val id = p.currentMediaItem?.mediaId ?: return
                    val cur = prefs.getStringSet("fav", emptySet())!!.toMutableSet()
                    if (!cur.add(id)) cur.remove(id)
                    prefs.edit().putStringSet("fav", cur).apply()
                }
                ACT_SEEK -> {
                    val d = p.duration
                    if (d != C.TIME_UNSET && d > 0) p.seekTo((d * ((i.getIntExtra("i", 0) + 0.5) / 10.0)).toLong())
                }
                ACT_VOL -> {
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * (i.getIntExtra("i", 0) + 1) / 10f), 0)
                }
                ACT_VOL_DOWN -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                ACT_VOL_UP -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
            }
            refresh()
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("tunes", Context.MODE_PRIVATE)
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Now playing", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        }
        val attrs = AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
        val player = ExoPlayer.Builder(this).setAudioAttributes(attrs, true).setHandleAudioBecomingNoisy(true).build()
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        session = MediaSession.Builder(this, player).setSessionActivity(open).build()
        setMediaNotificationProvider(StyledProvider())
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(ticker)
                if (isPlaying) handler.postDelayed(ticker, 1000)
            }
        })
        val f = IntentFilter().apply { addAction(ACT_FAV); addAction(ACT_SEEK); addAction(ACT_VOL); addAction(ACT_VOL_DOWN); addAction(ACT_VOL_UP) }
        ContextCompat.registerReceiver(this, actions, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        session?.player?.run { stop(); clearMediaItems() }
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        try { unregisterReceiver(actions) } catch (e: Exception) {}
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }

    private fun refresh() {
        val s = session ?: return
        val f = lastFactory ?: return
        if (s.player.mediaItemCount == 0) return
        val active = try { nm.activeNotifications.any { it.id == NOTIF_ID } } catch (e: Exception) { false }
        if (!active) return
        nm.notify(NOTIF_ID, build(s, f))
    }

    private inner class StyledProvider : MediaNotification.Provider {
        override fun createNotification(
            mediaSession: MediaSession,
            customLayout: ImmutableList<CommandButton>,
            actionFactory: MediaNotification.ActionFactory,
            onNotificationChangedCallback: MediaNotification.Provider.Callback
        ): MediaNotification {
            lastFactory = actionFactory
            return MediaNotification(NOTIF_ID, build(mediaSession, actionFactory))
        }

        override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean = false
    }

    private fun bc(code: Int, action: String, idx: Int = 0): PendingIntent {
        val i = Intent(action).setPackage(packageName).putExtra("i", idx)
        return PendingIntent.getBroadcast(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun fmt(ms: Long): String {
        val t = (ms / 1000).coerceAtLeast(0)
        return (t / 60).toString() + ":" + (t % 60).toString().padStart(2, '0')
    }

    private fun build(s: MediaSession, f: MediaNotification.ActionFactory): Notification {
        val p = s.player
        val item = p.currentMediaItem
        val md = item?.mediaMetadata
        val title = md?.title?.toString() ?: "Tunes"
        val artist = md?.artist?.toString() ?: ""
        val id = item?.mediaId ?: ""
        if (id != cacheId) { loadArt(item); cacheId = id }
        val playing = p.playWhenReady && p.playbackState != Player.STATE_ENDED
        val dur = if (p.duration == C.TIME_UNSET) 0L else p.duration
        val pos = p.currentPosition.coerceAtLeast(0)
        val fav = prefs.getStringSet("fav", emptySet())!!.contains(id)

        val prev = f.createMediaActionPendingIntent(s, Player.COMMAND_SEEK_TO_PREVIOUS.toLong())
        val next = f.createMediaActionPendingIntent(s, Player.COMMAND_SEEK_TO_NEXT.toLong())
        val pp = f.createMediaActionPendingIntent(s, Player.COMMAND_PLAY_PAUSE.toLong())
        val stop = f.createMediaActionPendingIntent(s, Player.COMMAND_STOP.toLong())

        val small = RemoteViews(packageName, R.layout.notif_small).apply {
            setImageViewBitmap(R.id.nt_bg, bg)
            setImageViewBitmap(R.id.nt_cover, cover)
            setTextViewText(R.id.nt_title, title)
            setTextViewText(R.id.nt_artist, artist)
            setImageViewResource(R.id.nt_prev, R.drawable.nt_prev)
            setImageViewResource(R.id.nt_play, if (playing) R.drawable.nt_pause else R.drawable.nt_play)
            setImageViewResource(R.id.nt_next, R.drawable.nt_next)
            setOnClickPendingIntent(R.id.nt_prev, prev)
            setOnClickPendingIntent(R.id.nt_play, pp)
            setOnClickPendingIntent(R.id.nt_next, next)
        }

        val big = RemoteViews(packageName, R.layout.notif_big).apply {
            setImageViewBitmap(R.id.nt_bg, bg)
            setImageViewBitmap(R.id.nt_cover, cover)
            setTextViewText(R.id.nt_title, title)
            setTextViewText(R.id.nt_artist, artist)
            setTextViewText(R.id.nt_pos, fmt(pos))
            setTextViewText(R.id.nt_rem, "-" + fmt(if (dur > 0) dur - pos else 0))
            setProgressBar(R.id.nt_prog, 1000, if (dur > 0) (pos * 1000 / dur).toInt().coerceIn(0, 1000) else 0, false)
            setImageViewResource(R.id.nt_fav, if (fav) R.drawable.nt_heart_on else R.drawable.nt_heart)
            setImageViewResource(R.id.nt_prev, R.drawable.nt_prev)
            setImageViewResource(R.id.nt_play, if (playing) R.drawable.nt_pause else R.drawable.nt_play)
            setImageViewResource(R.id.nt_next, R.drawable.nt_next)
            setImageViewResource(R.id.nt_vlow, R.drawable.nt_vol_low)
            setImageViewResource(R.id.nt_vhigh, R.drawable.nt_vol_high)
            setOnClickPendingIntent(R.id.nt_fav, bc(1, ACT_FAV))
            setOnClickPendingIntent(R.id.nt_prev, prev)
            setOnClickPendingIntent(R.id.nt_play, pp)
            setOnClickPendingIntent(R.id.nt_next, next)
            setOnClickPendingIntent(R.id.nt_vlow, bc(2, ACT_VOL_DOWN))
            setOnClickPendingIntent(R.id.nt_vhigh, bc(3, ACT_VOL_UP))
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            setProgressBar(R.id.nt_vol, 1000, am.getStreamVolume(AudioManager.STREAM_MUSIC) * 1000 / max, false)
            for (n in 0 until 10) {
                setOnClickPendingIntent(SEEK_IDS[n], bc(100 + n, ACT_SEEK, n))
                setOnClickPendingIntent(VOL_IDS[n], bc(200 + n, ACT_VOL, n))
            }
        }

        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(small)
            .setCustomBigContentView(big)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(s.sessionActivity)
            .setDeleteIntent(stop)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    // ---- artwork + gradient card ----
    private fun loadArt(item: MediaItem?) {
        val seed = (item?.mediaId?.toLongOrNull() ?: 0L)
        var art: Bitmap? = null
        val uri = item?.localConfiguration?.uri
        if (uri != null) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(this, uri)
                val b = r.embeddedPicture
                if (b != null) {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(b, 0, b.size, o)
                    var sm = 1
                    while (o.outWidth / (sm * 2) >= 300) sm *= 2
                    art = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = sm })
                }
            } catch (e: Exception) {
            } finally {
                try { r.release() } catch (e: Exception) {}
            }
            if (art == null && Build.VERSION.SDK_INT >= 29) {
                try { art = contentResolver.loadThumbnail(uri, Size(300, 300), null) } catch (e: Exception) {}
            }
        }
        val (c1, c2) = palette(art, seed)
        cover = roundedCover(art, c1, c2)
        bg = card(c1, c2)
    }

    private fun palette(b: Bitmap?, seed: Long): Pair<Int, Int> {
        if (b == null) {
            val h = ((seed * 47) % 360).toFloat()
            return Color.HSVToColor(floatArrayOf(h, .55f, 1f)) to Color.HSVToColor(floatArrayOf((h + 45f) % 360f, .55f, 1f))
        }
        val s = Bitmap.createScaledBitmap(b, 4, 4, true)
        val hsv = FloatArray(3)
        var b1 = Color.LTGRAY; var b2 = Color.LTGRAY; var s1 = -1f; var s2 = -1f
        for (x in 0 until 4) for (y in 0 until 4) {
            val c = s.getPixel(x, y)
            Color.colorToHSV(c, hsv)
            val sc = hsv[1] * (0.4f + hsv[2])
            if (sc > s1) { b2 = b1; s2 = s1; b1 = c; s1 = sc } else if (sc > s2) { b2 = c; s2 = sc }
        }
        return b1 to b2
    }

    private fun roundedCover(art: Bitmap?, c1: Int, c2: Int): Bitmap {
        val sz = 240
        val out = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = RectF(0f, 0f, sz.toFloat(), sz.toFloat())
        if (art != null) {
            val side = minOf(art.width, art.height)
            val sq = Bitmap.createBitmap(art, (art.width - side) / 2, (art.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(sq, sz, sz, true)
            p.shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        } else {
            p.shader = LinearGradient(0f, 0f, sz.toFloat(), sz.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        }
        cv.drawRoundRect(rect, 52f, 52f, p)
        if (art == null) {
            val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 120f; textAlign = Paint.Align.CENTER }
            cv.drawText("\u266A", sz / 2f, sz / 2f + 42f, t)
        }
        return out
    }

    private fun card(c1: Int, c2: Int): Bitmap {
        val w = 720; val h = 400
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val a = ColorUtils.blendARGB(c1, Color.WHITE, .42f)
        val b = ColorUtils.blendARGB(c2, Color.WHITE, .45f)
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), 56f, 56f, Path.Direction.CW) }
        cv.clipPath(clip)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), intArrayOf(0xFFEFEDED.toInt(), a, b), floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.shader = RadialGradient(w * .78f, h * .1f, w * .6f, ColorUtils.setAlphaComponent(a, 230), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), g)
        val fr = Paint(Paint.ANTI_ALIAS_FLAG)
        fr.shader = LinearGradient(0f, h * .35f, 0f, h.toFloat(), 0x00FFFFFF, 0x66FFFFFF, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fr)
        return out
    }

    companion object {
        const val CHANNEL = "tunes_playback"
        const val NOTIF_ID = 1001
        const val ACT_FAV = "com.tunes.app.NT_FAV"
        const val ACT_SEEK = "com.tunes.app.NT_SEEK"
        const val ACT_VOL = "com.tunes.app.NT_VOL"
        const val ACT_VOL_DOWN = "com.tunes.app.NT_VOL_DOWN"
        const val ACT_VOL_UP = "com.tunes.app.NT_VOL_UP"
        val SEEK_IDS = intArrayOf(R.id.nt_seek0, R.id.nt_seek1, R.id.nt_seek2, R.id.nt_seek3, R.id.nt_seek4, R.id.nt_seek5, R.id.nt_seek6, R.id.nt_seek7, R.id.nt_seek8, R.id.nt_seek9)
        val VOL_IDS = intArrayOf(R.id.nt_vs0, R.id.nt_vs1, R.id.nt_vs2, R.id.nt_vs3, R.id.nt_vs4, R.id.nt_vs5, R.id.nt_vs6, R.id.nt_vs7, R.id.nt_vs8, R.id.nt_vs9)
    }
}
