package com.tunes.app

import android.app.admin.DeviceAdminReceiver

// Only used for the "lock screen" permission (double-tap in the full player)
class LockAdmin : DeviceAdminReceiver()
