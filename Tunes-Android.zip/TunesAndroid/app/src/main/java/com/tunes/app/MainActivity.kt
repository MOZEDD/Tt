package com.tunes.app

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.WindowCompat
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.content.SharedPreferences
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.view.WindowManager
import android.view.View
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.layout.offset
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

var Accent by mutableStateOf(Color(0xFFFA2D55))

var Ios27 by mutableStateOf(true)
var ListScale by mutableFloatStateOf(1f)   // song list size (Themes > List size)
val RC: Dp get() = if (Ios27) 20.dp else 14.dp      // card / row radius
val RS: Dp get() = if (Ios27) 14.dp else 10.dp      // small radius
val RPill: Dp get() = if (Ios27) 50.dp else 18.dp   // chips / tabs
val RSearch: Dp get() = if (Ios27) 50.dp else 14.dp

class Pal(val bg: Color, val card: Color, val tx: Color, val tx2: Color, val fill: Color, val dark: Boolean = false)
val LightPal = Pal(Color(0xFFF2F2F7), Color.White, Color(0xFF111114), Color(0xFF8A8A92), Color(0x1F767680))
val DarkPal = Pal(Color.Black, Color(0xFF141416), Color(0xFFF5F5F7), Color(0xFF9A9AA1), Color(0x3D767680), true)
val IosLightPal = Pal(Color(0xFFF2F2F7), Color.White, Color(0xFF000000), Color(0xFF8E8E93), Color(0x1F767680))
val IosDarkPal = Pal(Color.Black, Color(0xFF1C1C1E), Color(0xFFFFFFFF), Color(0xFF98989F), Color(0x3D767680), true)
val LocalPal = staticCompositionLocalOf { LightPal }

// Liquid Glass switch (Glossy theme): oversized glass thumb with an inner pill
@Composable
fun GlassSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val track by animateColorAsState(if (checked) Color(0xFF05C84A) else Color(0xFFDDE3DF), tween(220), label = "gsTrack")
    val inner by animateColorAsState(if (checked) Color(0xFF14D257) else Color(0xFFEBEBEB), tween(220), label = "gsInner")
    val fillA by animateFloatAsState(if (checked) 0.22f else 1f, tween(220), label = "gsFill")
    val x by animateDpAsState(if (checked) 24.dp else 0.dp, spring(dampingRatio = 0.65f, stiffness = 450f), label = "gsX")
    val pill = RoundedCornerShape(50)
    val rim = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.98f), Color.White.copy(alpha = if (checked) 0.5f else 0.85f)))
    Box(
        Modifier.size(width = 66.dp, height = 34.dp)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onCheckedChange, interactionSource = remember { MutableInteractionSource() }, indication = null)
    ) {
        Box(Modifier.align(Alignment.CenterStart).padding(start = 4.dp).size(width = 58.dp, height = 22.dp).clip(pill).background(track))
        Box(
            Modifier.offset(x = x, y = 2.dp).size(width = 42.dp, height = 30.dp)
                .shadow(if (checked) 0.dp else 4.dp, pill, ambientColor = Color.Black.copy(alpha = 0.18f), spotColor = Color.Black.copy(alpha = 0.18f))
                .clip(pill).background(Color.White.copy(alpha = fillA)).border(2.dp, rim, pill),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(width = 28.dp, height = 18.dp).clip(pill).background(inner))
        }
    }
}

// Wide pill switch (iOS 27 style): used in the Classic theme
@Composable
fun TunesSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    if (Ios27) { GlassSwitch(checked, onCheckedChange); return }
    val track by animateColorAsState(if (checked) Color(0xFF04C84A) else Color(0xFFE9E9EA), tween(200), label = "swTrack")
    val x by animateDpAsState(if (checked) 24.dp else 2.dp, spring(dampingRatio = 0.7f, stiffness = 500f), label = "swX")
    Box(
        Modifier.size(width = 58.dp, height = 28.dp).clip(RoundedCornerShape(50)).background(track)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onCheckedChange, interactionSource = remember { MutableInteractionSource() }, indication = null)
    ) {
        Box(
            Modifier.offset(x = x, y = 2.dp).size(width = 32.dp, height = 24.dp).clip(RoundedCornerShape(50)).background(Color.White)
                .border(1.5.dp, track, RoundedCornerShape(50))
        )
    }
}

// Liquid Glass menu (Glossy theme): rounded popup, hairline dividers, soft edge highlight.
// classicBg = true keeps the standard (Classic) opaque menu background instead of the frosted glass one.
@Composable
fun GlassMenu(expanded: Boolean, onDismissRequest: () -> Unit, modifier: Modifier = Modifier, tint: Color? = null, classicBg: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    if (!Ios27) {
        DropdownMenu(expanded = expanded, onDismissRequest = onDismissRequest, modifier = modifier, content = content)
        return
    }
    val cs = MaterialTheme.colorScheme
    val dark = LocalPal.current.dark
    val ctx = LocalContext.current
    // real frosted blur of whatever is behind the menu (Android 12+, when the system allows window blur)
    val blurOk = !classicBg && remember {
        Build.VERSION.SDK_INT >= 31 && try { (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled } catch (e: Exception) { false }
    }
    val fill = if (classicBg) cs.surfaceContainer else (tint ?: cs.surfaceContainer).copy(alpha = if (blurOk) (if (dark) .50f else .58f) else (if (dark) .80f else .84f))
    val shape = RoundedCornerShape(28.dp)
    val edge = Brush.linearGradient(listOf(Color.White.copy(alpha = if (dark) .38f else .95f), Color.White.copy(alpha = if (dark) .06f else .30f)))
    MaterialTheme(colorScheme = cs.copy(surface = fill, surfaceContainer = fill), shapes = Shapes(extraSmall = shape, extraLarge = RoundedCornerShape(30.dp))) {
        DropdownMenu(expanded = expanded, onDismissRequest = onDismissRequest, modifier = modifier.border(0.6.dp, edge, shape)) {
            if (blurOk) BlurBehindWindow(48)
            content()
        }
    }
}

// Blurs the content behind the popup window this composable lives in (menus are popups)
@Composable
fun BlurBehindWindow(radius: Int) {
    val view = LocalView.current
    DisposableEffect(view) {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val root = view.rootView
                val lp = root.layoutParams as? WindowManager.LayoutParams
                if (lp != null) {
                    lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                    lp.blurBehindRadius = radius
                    (view.context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(root, lp)
                }
            } catch (e: Exception) {}
        }
        onDispose {}
    }
}

@Composable
fun GlassDivider() {
    if (!Ios27) return
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(0.5.dp).background(LocalPal.current.tx.copy(alpha = .14f)))
}

// Vivid cover-color gradient used behind the full player and the Glossy mini player
fun vividBrush(cover: Color, bgc: Color, dk: Boolean): Brush {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(cover.toArgb(), hsv)
    hsv[1] = if (dk) (hsv[1] * 1.25f).coerceAtMost(1f) else (hsv[1] * 1.25f).coerceIn(0f, .72f)
    hsv[2] = if (dk) hsv[2].coerceIn(.5f, .8f) else hsv[2].coerceIn(.9f, 1f)
    val base = Color(android.graphics.Color.HSVToColor(hsv))
    return Brush.verticalGradient(listOf(
        lerp(bgc, base, if (dk) .55f else .6f),
        lerp(bgc, base, .85f),
        lerp(bgc, base, if (dk) .45f else .5f)
    ))
}

// Back chevron drawn from its exact bounding-box center so it sits in the middle of its circle
@Composable
fun BackChevron(color: Color) {
    Canvas(Modifier.size(18.dp)) {
        val w = 6.dp.toPx(); val h = 11.dp.toPx(); val sw = 2.2.dp.toPx()
        val cx = size.width / 2f; val cy = size.height / 2f
        val apex = androidx.compose.ui.geometry.Offset(cx - w / 2f, cy)
        drawLine(color, androidx.compose.ui.geometry.Offset(cx + w / 2f, cy - h / 2f), apex, strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(color, androidx.compose.ui.geometry.Offset(cx + w / 2f, cy + h / 2f), apex, strokeWidth = sw, cap = StrokeCap.Round)
    }
}

// Glossy rim helpers (thin light ring on dark, soft gray ring on light)
fun glassRing(dark: Boolean, selected: Boolean = false, container: Boolean = false): Brush = Brush.linearGradient(
    if (dark) listOf(Color.White.copy(alpha = if (selected) .65f else if (container) .45f else .30f), Color.White.copy(alpha = if (selected) .15f else .06f))
    else listOf(Color.Black.copy(alpha = if (selected) .10f else if (container) .14f else .10f), Color.Black.copy(alpha = .03f))
)
fun rowFill(p: Pal): Color = if (!Ios27) p.card else if (p.dark) Color.White.copy(alpha = .06f) else Color.White.copy(alpha = .75f)
fun Modifier.rim(shape: androidx.compose.ui.graphics.Shape, dark: Boolean): Modifier = if (!Ios27) this else this.border(1.dp, glassRing(dark), shape)

// iOS 27 materials (Figma: iOS and iPadOS 27 Community, node 510:78330), effective tint over mid-gray
enum class Mat { Ultrathin, Thin, Regular, Thick, Chrome }
fun matColor(m: Mat, dark: Boolean): Color = if (dark) when (m) {
    Mat.Ultrathin -> Color.Black.copy(alpha = .02f)
    Mat.Thin -> Color.Black.copy(alpha = .26f)
    Mat.Regular -> Color.Black.copy(alpha = .41f)
    Mat.Thick -> Color.Black.copy(alpha = .60f)
    Mat.Chrome -> Color(0xFF1C1C1C).copy(alpha = .90f)
} else when (m) {
    Mat.Ultrathin -> Color.White.copy(alpha = .10f)
    Mat.Thin -> Color.White.copy(alpha = .44f)
    Mat.Regular -> Color.White.copy(alpha = .78f)
    Mat.Thick -> Color.White.copy(alpha = .91f)
    Mat.Chrome -> Color.White.copy(alpha = .75f)
}

// iOS 27 "Liquid Glass" style surface: translucent fill + thin specular edge
fun Modifier.glass(shape: androidx.compose.ui.graphics.Shape, dark: Boolean, mat: Mat = Mat.Thin, fill: Color? = null): Modifier =
    this.clip(shape)
        .background(fill ?: matColor(mat, dark))
        .border(0.6.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = if (dark) .35f else .9f), Color.White.copy(alpha = if (dark) .05f else .25f))), shape)

data class Track(val id: Long, val title: String, val artist: String, val album: String, val dur: Long, val uri: Uri, val folder: String = "") {
    fun item(): MediaItem = MediaItem.Builder().setMediaId(id.toString()).setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build()).build()
}

data class Pl(val id: String, val name: String, val ids: List<Long>)

data class Ed(val t: String, val a: String, val b: String)

fun loadEdits(s: String?): Map<Long, Ed> = try {
    if (s == null) emptyMap() else {
        val o = JSONObject(s)
        o.keys().asSequence().associate { k -> val e = o.getJSONObject(k); k.toLong() to Ed(e.getString("t"), e.getString("a"), e.getString("b")) }
    }
} catch (e: Exception) { emptyMap() }

fun saveEdits(m: Map<Long, Ed>): String {
    val o = JSONObject()
    m.forEach { (k, v) -> o.put(k.toString(), JSONObject().put("t", v.t).put("a", v.a).put("b", v.b)) }
    return o.toString()
}

fun loadPls(s: String?): List<Pl> = try {
    if (s == null) emptyList() else {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val ia = o.getJSONArray("ids")
            Pl(o.getString("id"), o.getString("name"), (0 until ia.length()).map { ia.getLong(it) })
        }
    }
} catch (e: Exception) { emptyList() }

fun fmt(ms: Long): String { val s = (ms.coerceAtLeast(0) / 1000).toInt(); return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }

object Boot { @Volatile var ready = false }

fun readTrackCache(c: Context): List<Track> = try {
    val f = java.io.File(c.filesDir, "tracks.json")
    if (!f.exists()) emptyList() else {
        val a = JSONArray(f.readText())
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val id = o.getLong("i")
            Track(id, o.getString("t"), o.getString("a"), o.getString("b"), o.getLong("d"), ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id), o.optString("f", ""))
        }.filter { it.dur >= 60000L }
    }
} catch (e: Exception) { emptyList() }

fun writeTrackCache(c: Context, l: List<Track>) {
    try {
        val a = JSONArray()
        l.forEach { t -> a.put(JSONObject().put("i", t.id).put("t", t.title).put("a", t.artist).put("b", t.album).put("d", t.dur).put("f", t.folder)) }
        java.io.File(c.filesDir, "tracks.json").writeText(a.toString())
    } catch (e: Exception) {}
}

fun loadTracks(c: Context): List<Track> {
    val out = ArrayList<Track>()
    val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA)
    val sel = "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND ${MediaStore.Audio.Media.DURATION}>=60000 AND ${MediaStore.Audio.Media.SIZE}>=102400"
    c.contentResolver.query(m, proj, sel, null, "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { q ->
        while (q.moveToNext()) {
            val id = q.getLong(0)
            val artist = q.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown Artist"
            out.add(Track(id, q.getString(1) ?: "Untitled", artist, q.getString(3) ?: "", q.getLong(4), ContentUris.withAppendedId(m, id), q.getString(5)?.substringBeforeLast('/', "") ?: ""))
        }
    }
    return out
}

object ArtCache {
    private val small = object : LruCache<Long, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }
    private val large = LruCache<Long, Bitmap>(4)
    private val none = java.util.Collections.synchronizedSet(HashSet<Long>())
    private val sem = Semaphore(3)
    private fun cacheFor(big: Boolean) = if (big) large else small
    fun peek(id: Long, big: Boolean): ImageBitmap? = cacheFor(big).get(id)?.asImageBitmap()
    suspend fun loadAsync(c: Context, t: Track, big: Boolean): ImageBitmap? =
        sem.withPermit { withContext(Dispatchers.IO) { load(c, t, big) } }
    private fun artFile(c: Context, id: Long, ext: String) = java.io.File(java.io.File(c.cacheDir, "art"), "$id.$ext")
    private fun load(c: Context, t: Track, big: Boolean): ImageBitmap? {
        val cache = cacheFor(big)
        cache.get(t.id)?.let { return it.asImageBitmap() }
        if (t.id in none) return null
        if (!big) {
            val f = artFile(c, t.id, "jpg")
            if (f.exists()) {
                val d = BitmapFactory.decodeFile(f.path)
                if (d != null) { cache.put(t.id, d); return d.asImageBitmap() }
            }
            if (artFile(c, t.id, "none").exists()) { none.add(t.id); return null }
        }
        val maxPx = if (big) 900 else 256
        var bm: Bitmap? = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(c, t.uri)
            val b = r.embeddedPicture
            if (b != null) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(b, 0, b.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= maxPx) s *= 2
                bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            }
        } catch (e: Exception) {
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
        if (bm == null && Build.VERSION.SDK_INT >= 29) {
            try { bm = c.contentResolver.loadThumbnail(t.uri, Size(maxPx, maxPx), null) } catch (e: Exception) {}
        }
        var out: Bitmap = bm ?: run {
            none.add(t.id)
            if (!big) {
                try { val m = artFile(c, t.id, "none"); m.parentFile?.mkdirs(); m.createNewFile() } catch (e: Exception) {}
            }
            return null
        }
        if (!big && out.width > 200) {
            val h = (out.height * 200f / out.width).toInt().coerceAtLeast(1)
            out = Bitmap.createScaledBitmap(out, 200, h, true)
        }
        cache.put(t.id, out)
        if (!big) {
            try {
                val f = artFile(c, t.id, "jpg")
                f.parentFile?.mkdirs()
                java.io.FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            } catch (e: Exception) {}
        }
        return out.asImageBitmap()
    }
}

class PosState { var ms by mutableLongStateOf(0L) }

fun grad(id: Long): Brush {
    val h = ((id * 47) % 360).toFloat()
    return Brush.linearGradient(listOf(Color.hsv(h, .65f, .92f), Color.hsv((h + 50f) % 360f, .75f, .72f)))
}

@Composable
fun Cover(t: Track?, modifier: Modifier, radius: Dp = 9.dp, big: Boolean = false) {
    val ctx = LocalContext.current
    var bmp by remember(t?.id, big) { mutableStateOf(t?.let { ArtCache.peek(it.id, big) ?: ArtCache.peek(it.id, false) }) }
    LaunchedEffect(t?.id, big) {
        if (t != null && ArtCache.peek(t.id, big) == null) {
            if (!big) delay(100)
            val r = ArtCache.loadAsync(ctx, t, big)
            if (r != null) bmp = r
        }
    }
    val b = bmp
    Box(modifier.clip(RoundedCornerShape(radius)).background(grad(t?.id ?: 0L)), contentAlignment = Alignment.Center) {
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.fillMaxSize(.4f))
    }
}

@Composable
fun MiniBar(ps: PosState, total: Long, modifier: Modifier) {
    val frac = if (total > 0) (ps.ms.toFloat() / total).coerceIn(0f, 1f) else 0f
    Box(modifier.fillMaxWidth(frac).height(2.dp).background(Accent))
}

@Composable
fun Bar(frac: Float, fg: Color, thumb: Boolean, onChange: (Float) -> Unit, onDone: () -> Unit, barH: Dp = 4.dp) {
    var w by remember { mutableFloatStateOf(1f) }
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    val f = frac.coerceIn(0f, 1f)
    val density = LocalDensity.current
    Box(
        Modifier.fillMaxWidth().height(28.dp)
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { o -> change((o.x / w).coerceIn(0f, 1f)); done() } }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> change((o.x / w).coerceIn(0f, 1f)) },
                    onDragEnd = { done() },
                    onDragCancel = { done() },
                    onHorizontalDrag = { ch, _ -> change((ch.position.x / w).coerceIn(0f, 1f)) }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(Modifier.fillMaxWidth().height(barH).clip(CircleShape).background(fg.copy(alpha = .25f)))
        Box(Modifier.fillMaxWidth(f).height(barH).clip(CircleShape).background(fg))
        if (thumb) {
            val half = with(density) { 7.dp.toPx() }
            Box(Modifier.offset { IntOffset((f * w - half).roundToInt(), 0) }.size(14.dp).clip(CircleShape).background(fg))
        }
    }
}

@Composable
fun PlayerSeek(ps: PosState, total: Long, fg: Color, onDrag: () -> Unit, onDone: (Long) -> Unit) {
    val frac = if (total > 0) ps.ms.toFloat() / total else 0f
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(fmt(ps.ms), color = fg.copy(alpha = .6f), fontSize = 13.sp, maxLines = 1, softWrap = false, modifier = Modifier.widthIn(min = 36.dp))
        Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            Bar(frac, fg, !Ios27, { f -> onDrag(); ps.ms = (f * total).toLong() }, { onDone(ps.ms) }, if (Ios27) 7.dp else 5.dp)
        }
        Text("-" + fmt(total - ps.ms), color = fg.copy(alpha = .6f), fontSize = 13.sp, maxLines = 1, softWrap = false, textAlign = androidx.compose.ui.text.style.TextAlign.End, modifier = Modifier.widthIn(min = 42.dp))
    }
}

@Composable
fun coverColor(t: Track): State<Color> {
    val ctx = LocalContext.current
    val fb = remember(t.id) { Color.hsv(((t.id * 47) % 360).toFloat(), .6f, .55f) }
    var col by remember(t.id) { mutableStateOf(fb) }
    LaunchedEffect(t.id) {
        val avg = withContext(Dispatchers.IO) {
            try {
                val img = ArtCache.peek(t.id, false) ?: ArtCache.loadAsync(ctx, t, false)
                if (img == null) null else {
                    val b = Bitmap.createScaledBitmap(img.asAndroidBitmap(), 8, 8, true)
                    var r = 0; var g = 0; var bl = 0
                    for (x in 0 until 8) for (y in 0 until 8) {
                        val px = b.getPixel(x, y)
                        r += android.graphics.Color.red(px); g += android.graphics.Color.green(px); bl += android.graphics.Color.blue(px)
                    }
                    Color(r / 64, g / 64, bl / 64)
                }
            } catch (e: Exception) { null }
        }
        if (avg != null) col = avg
    }
    return animateColorAsState(col, tween(500), label = "cover")
}

@Composable
fun IconBtn(icon: ImageVector, tint: Color? = null, box: Dp = 44.dp, size: Dp = 26.dp, onClick: () -> Unit) {
    Box(Modifier.size(box).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint ?: LocalPal.current.tx, modifier = Modifier.size(size))
    }
}

// Full-player button: glass circle with a thin light ring in the Glossy theme, plain icon in Classic
@Composable
fun PlayerBtn(icon: ImageVector, tint: Color, dark: Boolean, classicBox: Dp = 44.dp, classicSize: Dp = 26.dp, box: Dp = 46.dp, size: Dp = 22.dp, neutralBg: Boolean = false, custom: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    if (!Ios27) { IconBtn(icon, tint, box = classicBox, size = classicSize, onClick = onClick); return }
    val fill = if (dark) Color.White.copy(alpha = .09f) else if (neutralBg) Color.White.copy(alpha = .85f) else Color.White.copy(alpha = .55f)
    val ring = if (neutralBg && !dark) Brush.linearGradient(listOf(Color.Black.copy(alpha = .14f), Color.Black.copy(alpha = .04f)))
        else Brush.linearGradient(listOf(Color.White.copy(alpha = if (dark) .55f else 1f), Color.White.copy(alpha = if (dark) .10f else .35f)))
    Box(Modifier.size(box).clip(CircleShape).background(fill).border(1.2.dp, ring, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        if (custom != null) custom() else Icon(icon, null, tint = tint, modifier = Modifier.size(size))
    }
}

@Composable
fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(Modifier.clip(RoundedCornerShape(RPill)).background(if (on) Accent else p.fill).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(label, color = if (on) Color.White else p.tx, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TrackRow(t: Track, on: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(RC)).background(rowFill(p)).rim(RoundedCornerShape(RC), p.dark).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = (13f * ListScale).dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(t.title, color = if (on) Accent else p.tx, fontSize = (17f * ListScale).sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist, color = p.tx2, fontSize = (14f * ListScale).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(12.dp))
        Text(fmt(t.dur), color = p.tx2, fontSize = (15f * ListScale).sp)
    }
}

@Composable
fun GhostRow(t: Track) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(RC)).background(rowFill(p)).rim(RoundedCornerShape(RC), p.dark).padding(horizontal = 16.dp, vertical = (13f * ListScale).dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(t.title, color = p.tx, fontSize = (17f * ListScale).sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist, color = p.tx2, fontSize = (14f * ListScale).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(12.dp))
        Text(fmt(t.dur), color = p.tx2, fontSize = (15f * ListScale).sp)
    }
}

fun audioPerm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
fun hasAudioPerm(c: Context) = ContextCompat.checkSelfPermission(c, audioPerm()) == PackageManager.PERMISSION_GRANTED

class RowItem(val key: String, val title: String, val sub: String, val trail: String, val kind: Int, val arg: String, val idx: Int)

@Composable
fun ListRow(title: String, sub: String, trail: String, hi: Boolean, chevron: Boolean, onClick: (() -> Unit)?, onRemove: (() -> Unit)? = null, onTrail: (() -> Unit)? = null, sel: Boolean? = null) {
    val p = LocalPal.current
    val base = Modifier.fillMaxWidth().clip(RoundedCornerShape(RC)).background(rowFill(p)).rim(RoundedCornerShape(RC), p.dark)
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Row(m.padding(horizontal = 16.dp, vertical = (13f * ListScale).dp), verticalAlignment = Alignment.CenterVertically) {
        if (sel != null) {
            Icon(if (sel) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null, tint = if (sel) Accent else p.tx2, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = if (hi) Accent else p.tx, fontSize = (17f * ListScale).sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, color = p.tx2, fontSize = (14f * ListScale).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trail.isNotEmpty()) {
            Spacer(Modifier.width(4.dp))
            val tm = if (onTrail != null) Modifier.clip(RoundedCornerShape(RS)).clickable(onClick = onTrail).padding(horizontal = 8.dp, vertical = 10.dp) else Modifier.padding(start = 8.dp)
            Text(trail, color = p.tx2, fontSize = (15f * ListScale).sp, modifier = tm)
        }
        if (chevron) Icon(Icons.Rounded.ChevronRight, null, tint = p.tx2, modifier = Modifier.size(22.dp))
        if (onRemove != null) { Spacer(Modifier.width(4.dp)); IconBtn(Icons.Rounded.Close, p.tx2, box = 36.dp, size = 20.dp, onClick = onRemove) }
    }
}

@Composable
fun RowsList(rows: List<RowItem>, state: LazyListState, curId: Long?, miniOn: Boolean, empty: String, removable: Boolean, onSize: (Int) -> Unit, onRow: (RowItem) -> Unit, onRemove: (RowItem) -> Unit, onTime: (RowItem) -> Unit = {}, selSet: Set<Long>? = null) {
    val p = LocalPal.current
    val curKey = curId?.toString()
    if (rows.isEmpty()) {
        Text(empty, color = p.tx2, fontSize = 15.sp, modifier = Modifier.fillMaxWidth().padding(36.dp))
    } else {
        LazyColumn(
            Modifier.fillMaxSize().onSizeChanged { onSize(it.height) },
            state = state,
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = if (miniOn) 130.dp else 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(rows, key = { it.key }) { r ->
                ListRow(
                    r.title, r.sub, r.trail,
                    (r.kind == 0 && r.arg == curKey) || r.kind == 4,
                    r.kind in 1..3,
                    { onRow(r) },
                    if (removable && r.kind == 0) ({ onRemove(r) }) else null,
                    if (r.kind == 0) ({ onTime(r) }) else null,
                    if (selSet != null && r.kind == 0) (r.arg.toLong() in selSet) else null
                )
            }
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun TabChips(pager: PagerState, showSort: Boolean, extra: @Composable () -> Unit, onTab: (Int) -> Unit) {
    val p = LocalPal.current
    val labels = listOf("All", "Artists", "Albums", "Playlists")
    if (Ios27) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            val ringC = Brush.linearGradient(listOf(if (p.dark) Color.White.copy(alpha = .45f) else Color.Black.copy(alpha = .14f), if (p.dark) Color.White.copy(alpha = .08f) else Color.Black.copy(alpha = .04f)))
            val ringS = Brush.linearGradient(listOf(if (p.dark) Color.White.copy(alpha = .65f) else Color.Black.copy(alpha = .10f), if (p.dark) Color.White.copy(alpha = .15f) else Color.Black.copy(alpha = .03f)))
            Row(Modifier.weight(1f).height(42.dp).clip(CircleShape).background(if (p.dark) Color.White.copy(alpha = .05f) else Color.Black.copy(alpha = .04f)).border(1.2.dp, ringC, CircleShape).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                labels.forEachIndexed { i, label ->
                    val on = pager.currentPage == i
                    Box(Modifier.weight(1f).fillMaxHeight().then(if (on) Modifier.then(if (p.dark) Modifier else Modifier.shadow(3.dp, CircleShape)).clip(CircleShape).background(if (p.dark) Color.White.copy(alpha = .13f) else Color.White).border(1.2.dp, ringS, CircleShape) else Modifier.clip(CircleShape)).clickable { onTab(i) }, contentAlignment = Alignment.Center) {
                        Text(label, color = if (on) Accent else p.tx, fontSize = 13.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium, maxLines = 1, softWrap = false)
                    }
                }
            }
            Box(Modifier.width(42.dp).height(42.dp), contentAlignment = Alignment.Center) {
                if (showSort && pager.currentPage == 0) extra()
            }
        }
        return
    }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        labels.forEachIndexed { i, label ->
            val on = pager.currentPage == i
            Box(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(if (on) Accent else p.fill).clickable { onTab(i) }.padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                Text(label, color = if (on) Color.White else p.tx, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
            }
        }
        Box(Modifier.width(40.dp).height(38.dp), contentAlignment = Alignment.Center) {
            if (showSort && pager.currentPage == 0) extra()
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun CountRow(pager: PagerState, songs: Int, artists: Int, albums: Int, hiddenCount: Int, onRestore: () -> Unit) {
    val p = LocalPal.current
    val pg = pager.currentPage
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            when (pg) { 0 -> "$songs songs"; 1 -> "$artists artists"; 2 -> "$albums albums"; else -> "Playlists" },
            color = p.tx2, fontSize = 13.sp, modifier = Modifier.weight(1f)
        )
        if (pg == 0 && hiddenCount > 0) {
            Text("Restore $hiddenCount removed", color = Accent, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onRestore).padding(vertical = 6.dp))
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun MiniGhost(modifier: Modifier, pager: PagerState, inDetail: Boolean, rowsByPage: List<List<RowItem>>, detailRows: List<RowItem>, listStates: List<LazyListState>, detailState: LazyListState, listH: Int) {
    if (listH > 0) {
        val density = LocalDensity.current
        val rows = if (inDetail) detailRows else rowsByPage[pager.currentPage]
        val st = if (inDetail) detailState else listStates[pager.currentPage]
        val ghostState = rememberLazyListState()
        LaunchedEffect(st) {
            snapshotFlow { st.firstVisibleItemIndex to st.firstVisibleItemScrollOffset }
                .collect { (i, o) -> ghostState.scrollToItem(i, o) }
        }
        Box(modifier.clipToBounds().blur(if (Ios27) 28.dp else 22.dp)) {
            LazyColumn(
                Modifier.fillMaxWidth().requiredHeight(with(density) { listH.toDp() }).align(Alignment.BottomStart),
                state = ghostState,
                userScrollEnabled = false,
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 130.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) { items(rows, key = { it.key }) { r -> ListRow(r.title, r.sub, r.trail, false, r.kind in 1..3, null) } }
        }
    }
}

@Composable
fun MenuTheme(scheme: ColorScheme, base: State<Color>, bgc: Color, dk: Boolean, fg: Color, content: @Composable () -> Unit) {
    val mb = lerp(bgc, base.value, if (dk) .4f else .3f)
    MaterialTheme(
        colorScheme = scheme.copy(surface = mb, surfaceContainer = mb, onSurface = fg),
        shapes = Shapes(extraSmall = RoundedCornerShape(18.dp)),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !Boot.ready }
        Handler(Looper.getMainLooper()).postDelayed({ Boot.ready = true }, 1200)
        enableEdgeToEdge()
        getSharedPreferences("tunes", Context.MODE_PRIVATE).getInt("accent", 0).let { if (it != 0) Accent = Color(it) }
        Ios27 = getSharedPreferences("tunes", Context.MODE_PRIVATE).getBoolean("ios27", true)
        ListScale = getSharedPreferences("tunes", Context.MODE_PRIVATE).getFloat("list_scale", 1f).coerceIn(0.8f, 1.3f)
        try {
            @Suppress("DEPRECATION")
            val disp = windowManager.defaultDisplay
            val curMode = disp.mode
            val best = disp.supportedModes
                .filter { it.physicalWidth == curMode.physicalWidth && it.physicalHeight == curMode.physicalHeight }
                .maxByOrNull { it.refreshRate }
            if (best != null) {
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                lp.preferredRefreshRate = best.refreshRate
                window.attributes = lp
            }
        } catch (e: Exception) {
        }
        setContent { TunesApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TunesApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("tunes", Context.MODE_PRIVATE) }
    var themeMode by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
    val sysDark = isSystemInDarkTheme()
    val darkTheme = when (themeMode) { 1 -> false; 2 -> true; else -> sysDark }
    val pal = if (Ios27) (if (darkTheme) IosDarkPal else IosLightPal) else (if (darkTheme) DarkPal else LightPal)
    val barView = LocalView.current
    SideEffect {
        val w = (barView.context as? Activity)?.window
        if (w != null) {
            val ic = WindowCompat.getInsetsController(w, barView)
            ic.isAppearanceLightStatusBars = !darkTheme
            ic.isAppearanceLightNavigationBars = !darkTheme
        }
    }

    val focusManager = LocalFocusManager.current
    val kbc = LocalSoftwareKeyboardController.current
    var searchFocused by remember { mutableStateOf(false) }
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    var imeWas by remember { mutableStateOf(false) }
    LaunchedEffect(imeVisible) {
        if (imeWas && !imeVisible) focusManager.clearFocus()   // keyboard dismissed -> stop the search cursor
        imeWas = imeVisible
    }
    var granted by remember { mutableStateOf(hasAudioPerm(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasAudioPerm(ctx) }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm(), Manifest.permission.POST_NOTIFICATIONS) else arrayOf(audioPerm()))
        else if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) launcher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
    }
    var rawTracks by remember { mutableStateOf(emptyList<Track>()) }
    var edits by remember { mutableStateOf(loadEdits(prefs.getString("edits", null))) }
    var excluded by remember { mutableStateOf(prefs.getStringSet("excl", emptySet())!!.toSet()) }
    fun setExcluded(v: Set<String>) { excluded = v; prefs.edit().putStringSet("excl", v).apply() }
    val tracks = remember(rawTracks, edits, excluded) {
        val base = if (excluded.isEmpty()) rawTracks else rawTracks.filter { it.folder.isEmpty() || it.folder !in excluded }
        if (edits.isEmpty()) base else base.map { t -> edits[t.id]?.let { e -> t.copy(title = e.t, artist = e.a, album = e.b) } ?: t }
    }
    var infoTrack by remember { mutableStateOf<Track?>(null) }
    var editMode by remember { mutableStateOf(false) }
    var scanKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        val cached = withContext(Dispatchers.IO) { readTrackCache(ctx) }
        if (rawTracks.isEmpty()) rawTracks = cached
        Boot.ready = true
    }
    LaunchedEffect(granted, scanKey) {
        if (granted) {
            val fresh = withContext(Dispatchers.IO) { loadTracks(ctx) }
            if (fresh != rawTracks) {
                rawTracks = fresh
                withContext(Dispatchers.IO) { writeTrackCache(ctx, fresh) }
            }
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = object : LifecycleEventObserver {
            override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
                if (event == Lifecycle.Event.ON_RESUME) { granted = hasAudioPerm(ctx); scanKey++ }
                if (event == Lifecycle.Event.ON_PAUSE) focusManager.clearFocus()
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    var player by remember { mutableStateOf<Player?>(null) }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        f.addListener({ try { player = f.get() } catch (e: Exception) {} }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f) }
    }
    var curId by remember { mutableStateOf<Long?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var speed by remember { mutableFloatStateOf(1f) }
    var durMs by remember { mutableLongStateOf(0L) }
    val ps = remember { PosState() }
    var dragging by remember { mutableStateOf(false) }
    var qv by remember { mutableIntStateOf(0) }
    DisposableEffect(player) {
        val p = player
        if (p == null) {
            onDispose { }
        } else {
            fun sync() {
                curId = p.currentMediaItem?.mediaId?.toLongOrNull()
                isPlaying = p.isPlaying
                shuffle = p.shuffleModeEnabled
                repeat = p.repeatMode
                speed = p.playbackParameters.speed
                durMs = p.duration.coerceAtLeast(0L)
                qv++
            }
            val l = object : Player.Listener { override fun onEvents(pl: Player, events: Player.Events) { sync() } }
            p.addListener(l); sync()
            onDispose { p.removeListener(l) }
        }
    }
    LaunchedEffect(player) {
        val p = player ?: return@LaunchedEffect
        while (true) { if (!dragging) ps.ms = p.currentPosition; delay(400) }
    }

    fun saveIds() {
        val p = player ?: return
        if (p.mediaItemCount == 0) return
        val ids = (0 until p.mediaItemCount).joinToString(",") { p.getMediaItemAt(it).mediaId }
        prefs.edit().putString("last_ids", ids).putString("last_id", p.currentMediaItem?.mediaId ?: "").apply()
    }
    fun savePos() {
        val p = player ?: return
        if (p.mediaItemCount == 0) return
        prefs.edit().putLong("last_pos", p.currentPosition.coerceAtLeast(0L)).putString("last_id", p.currentMediaItem?.mediaId ?: "").apply()
    }
    LaunchedEffect(curId) { saveIds(); savePos() }
    LaunchedEffect(isPlaying) { savePos() }
    LaunchedEffect(player) {
        val p = player ?: return@LaunchedEffect
        while (true) { delay(5000); if (p.isPlaying) savePos() }
    }
    DisposableEffect(lifecycleOwner, player) {
        val o = object : LifecycleEventObserver {
            override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
                if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) { saveIds(); savePos() }
            }
        }
        lifecycleOwner.lifecycle.addObserver(o)
        onDispose { lifecycleOwner.lifecycle.removeObserver(o) }
    }

    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(0) }
    var favs by remember { mutableStateOf(prefs.getStringSet("fav", emptySet())!!.toSet()) }
    DisposableEffect(prefs) {
        val l = SharedPreferences.OnSharedPreferenceChangeListener { sp, k -> if (k == "fav") favs = sp.getStringSet("fav", emptySet())!!.toSet() }
        prefs.registerOnSharedPreferenceChangeListener(l)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(l) }
    }
    var hidden by remember { mutableStateOf(prefs.getStringSet("hidden", emptySet())!!.toSet()) }
    var pls by remember { mutableStateOf(loadPls(prefs.getString("pls", null))) }
    var recent by remember { mutableStateOf((prefs.getString("recent", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }) }
    var dlg by remember { mutableIntStateOf(0) }
    var menuOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    var selecting by remember { mutableStateOf(false) }
    var selIds by remember { mutableStateOf(emptySet<Long>()) }
    var pendingIds by remember { mutableStateOf<List<Long>?>(null) }
    var pendingAdd by remember { mutableStateOf<Track?>(null) }
    var detail by remember { mutableStateOf<String?>(null) }
    var showPlayer by remember { mutableStateOf(false) }
    var settingsPage by remember { mutableIntStateOf(0) }
    var blurOn by remember { mutableStateOf(prefs.getBoolean("blur", true)) }
    val pager = rememberPagerState { 4 }
    val pagerScope = rememberCoroutineScope()
    val ls0 = rememberLazyListState()
    val ls1 = rememberLazyListState()
    val ls2 = rememberLazyListState()
    val ls3 = rememberLazyListState()
    val listStates = listOf(ls0, ls1, ls2, ls3)
    val detailState = rememberLazyListState()
    var listH by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val q = query.trim()
    LaunchedEffect(detail) { detailState.scrollToItem(0) }

    LaunchedEffect(curId) {
        val id = curId
        if (id != null && recent.firstOrNull() != id) {
            recent = (listOf(id) + recent.filter { it != id }).take(50)
            prefs.edit().putString("recent", recent.joinToString(",")).apply()
        }
    }

    fun albumOf(t: Track): String = t.album.ifBlank { "Unknown Album" }
    fun hit(t: Track): Boolean = q.isEmpty() || (t.title + " " + t.artist + " " + t.album).contains(q, ignoreCase = true)
    fun sortSongs(l: List<Track>): List<Track> = when (sort) {
        1 -> l.sortedBy { it.title.lowercase() }
        2 -> l.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
        else -> l
    }

    val trackById = remember(tracks) { tracks.associateBy { it.id } }
    val visible = remember(tracks, hidden) { tracks.filter { it.id.toString() !in hidden } }
    val recentTracks = remember(recent, trackById) { recent.mapNotNull { trackById[it] } }
    var restored by remember { mutableStateOf(false) }
    LaunchedEffect(player, trackById) {
        val p = player ?: return@LaunchedEffect
        if (restored || trackById.isEmpty()) return@LaunchedEffect
        restored = true
        if (p.mediaItemCount > 0) return@LaunchedEffect   // already playing, keep the live queue
        val ids = (prefs.getString("last_ids", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }
        val lastId = prefs.getString("last_id", "")?.toLongOrNull()
        val list = ids.mapNotNull { trackById[it] }
        if (list.isEmpty()) return@LaunchedEffect
        val idx = list.indexOfFirst { it.id == lastId }.coerceAtLeast(0)
        p.setMediaItems(list.map { it.item() }, idx, prefs.getLong("last_pos", 0L))
        p.prepare()   // paused: shows the last song, press play to continue
    }
    val favTracks = remember(favs, tracks) { tracks.filter { it.id.toString() in favs } }

    val allSongs = remember(visible, q, sort) { sortSongs(visible.filter { hit(it) }) }
    val allRows = remember(allSongs) { allSongs.mapIndexed { i, t -> RowItem("s:" + t.id, t.title, t.artist, fmt(t.dur), 0, t.id.toString(), i) } }
    val artistRows = remember(visible, q) {
        visible.groupBy { it.artist }.entries
            .filter { q.isEmpty() || it.key.contains(q, ignoreCase = true) }
            .sortedBy { it.key.lowercase() }
            .map { RowItem("a:" + it.key, it.key, it.value.size.toString() + " songs", "", 1, it.key, 0) }
    }
    val albumRows = remember(visible, q) {
        visible.groupBy { albumOf(it) }.entries
            .filter { q.isEmpty() || it.key.contains(q, ignoreCase = true) }
            .sortedBy { it.key.lowercase() }
            .map { RowItem("b:" + it.key, it.key, it.value.first().artist + " - " + it.value.size + " songs", "", 2, it.key, 0) }
    }
    val plRows = remember(pls, recentTracks, favTracks, trackById) {
        val out = ArrayList<RowItem>()
        out.add(RowItem("new", "+ New playlist", "", "", 4, "", 0))
        out.add(RowItem("p:recent", "Recently Played", recentTracks.size.toString() + " songs", "", 3, "recent", 0))
        out.add(RowItem("p:fav", "Favourites", favTracks.size.toString() + " songs", "", 3, "fav", 0))
        pls.forEach { pl -> out.add(RowItem("p:" + pl.id, pl.name, pl.ids.count { trackById.containsKey(it) }.toString() + " songs", "", 3, pl.id, 0)) }
        out
    }
    val detailSongs = remember(detail, visible, favTracks, recentTracks, pls, trackById, q, sort) {
        val d = detail
        val base: List<Track> = when {
            d == null -> emptyList()
            d.startsWith("artist:") -> visible.filter { it.artist == d.removePrefix("artist:") }
            d.startsWith("album:") -> visible.filter { albumOf(it) == d.removePrefix("album:") }
            d == "pl:recent" -> recentTracks
            d == "pl:fav" -> favTracks
            else -> pls.firstOrNull { it.id == d.removePrefix("pl:") }?.ids?.mapNotNull { trackById[it] } ?: emptyList()
        }
        val f = base.filter { hit(it) }
        if (d != null && (d.startsWith("artist:") || d.startsWith("album:"))) sortSongs(f) else f
    }
    val detailRows = remember(detailSongs) { detailSongs.mapIndexed { i, t -> RowItem("s:" + t.id, t.title, t.artist, fmt(t.dur), 0, t.id.toString(), i) } }

    val cur = curId?.let { trackById[it] }
    BackHandler(enabled = detail != null && !showPlayer) { detail = null }
    BackHandler(enabled = settingsPage != 0 && !showPlayer) { settingsPage = if (settingsPage >= 2) 1 else 0 }
    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && settingsPage == 0 && (searchFocused || query.isNotEmpty())) { query = ""; focusManager.clearFocus(); kbc?.hide() }
    val total = if (durMs > 0) durMs else (cur?.dur ?: 0L)

    fun playFrom(list: List<Track>, i: Int) {
        val p = player ?: return
        p.setMediaItems(list.map { it.item() }, i, 0L); p.prepare(); p.play()
    }
    fun toggleFav(t: Track) {
        val k = t.id.toString()
        favs = if (k in favs) favs - k else favs + k
        prefs.edit().putStringSet("fav", favs).apply()
    }
    fun togglePlay() { val p = player ?: return; if (p.isPlaying) p.pause() else p.play() }
    fun savePls(l: List<Pl>) {
        pls = l
        val a = JSONArray()
        l.forEach { p -> a.put(JSONObject().put("id", p.id).put("name", p.name).put("ids", JSONArray(p.ids))) }
        prefs.edit().putString("pls", a.toString()).apply()
    }
    fun removeFromDetail(id: Long) {
        val d = detail ?: return
        when {
            d == "pl:fav" -> { favs = favs - id.toString(); prefs.edit().putStringSet("fav", favs).apply() }
            d == "pl:recent" -> { recent = recent.filter { it != id }; prefs.edit().putString("recent", recent.joinToString(",")).apply() }
            d.startsWith("pl:") -> { val pid = d.removePrefix("pl:"); savePls(pls.map { if (it.id == pid) it.copy(ids = it.ids - id) else it }) }
        }
    }
    fun inDetail(t: Track): Boolean {
        val d = detail ?: return false
        return if (d == "pl:fav") t.id.toString() in favs else (pls.firstOrNull { it.id == d.removePrefix("pl:") }?.ids?.contains(t.id) == true)
    }
    fun toggleInDetail(t: Track) {
        val d = detail ?: return
        if (d == "pl:fav") toggleFav(t) else {
            val pid = d.removePrefix("pl:")
            savePls(pls.map { if (it.id == pid) it.copy(ids = if (t.id in it.ids) it.ids - t.id else it.ids + t.id) else it })
        }
    }
    fun onRow(r: RowItem, songs: List<Track>) {
        when (r.kind) {
            0 -> playFrom(songs, r.idx)
            1 -> detail = "artist:" + r.arg
            2 -> detail = "album:" + r.arg
            3 -> detail = "pl:" + r.arg
            4 -> { pendingAdd = null; dlg = 1 }
        }
    }

    val dk = pal.dark
    val scheme = if (dk) darkColorScheme(primary = Accent, surface = pal.card, onSurface = pal.tx, background = pal.bg, surfaceTint = Color.Transparent)
        else lightColorScheme(primary = Accent, surface = pal.card, onSurface = pal.tx, background = pal.bg, surfaceTint = Color.Transparent)

    MaterialTheme(colorScheme = scheme, shapes = if (Ios27) Shapes(extraSmall = RoundedCornerShape(20.dp), extraLarge = RoundedCornerShape(30.dp)) else Shapes(extraSmall = RoundedCornerShape(16.dp))) {
    CompositionLocalProvider(LocalPal provides pal) {
        Box(Modifier.fillMaxSize().background(pal.bg)) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = if (Ios27) 16.dp else 10.dp, top = 10.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Tunes", fontSize = 34.sp, fontWeight = if (Ios27) FontWeight.Bold else FontWeight.ExtraBold, color = pal.tx, modifier = Modifier.weight(1f))
                    PlayerBtn(Icons.Rounded.Settings, if (Ios27) pal.tx else pal.tx2, pal.dark, box = 44.dp, size = 24.dp, neutralBg = true) { settingsPage = 1 }
                }
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().height(46.dp).clip(RoundedCornerShape(RSearch)).then(if (Ios27) Modifier.background(if (pal.dark) Color.White.copy(alpha = .05f) else Color.Black.copy(alpha = .04f)).border(1.2.dp, Brush.linearGradient(listOf(if (pal.dark) Color.White.copy(alpha = .45f) else Color.Black.copy(alpha = .14f), if (pal.dark) Color.White.copy(alpha = .08f) else Color.Black.copy(alpha = .04f))), CircleShape) else Modifier.background(pal.fill)).padding(horizontal = if (Ios27) 14.dp else 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Search, null, tint = pal.tx2, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Search", color = pal.tx2, fontSize = 17.sp)
                        BasicTextField(query, { query = it }, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 17.sp), cursorBrush = SolidColor(Accent), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus(); kbc?.hide() }), modifier = Modifier.fillMaxWidth().onFocusChanged { searchFocused = it.isFocused })
                    }
                }
                TabChips(pager, detail == null, {
                    Box {
                        PlayerBtn(Icons.Rounded.Menu, pal.tx, pal.dark, classicBox = 38.dp, classicSize = 22.dp, box = 42.dp, size = 22.dp, neutralBg = true) { sortOpen = false; menuOpen = true }
                        GlassMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }, tint = pal.card) {
                            if (!sortOpen) {
                                DropdownMenuItem(
                                    text = { Text("Select multiple", color = pal.tx, fontSize = if (Ios27) 17.sp else 16.sp) },
                                    leadingIcon = { Icon(Icons.Rounded.CheckCircle, null, tint = pal.tx2) },
                                    onClick = { menuOpen = false; selecting = true; selIds = emptySet() }
                                )
                                GlassDivider()
                                DropdownMenuItem(
                                    text = { Text("Sort by", color = pal.tx, fontSize = if (Ios27) 17.sp else 16.sp) },
                                    leadingIcon = { Icon(Icons.Rounded.Sort, null, tint = pal.tx2) },
                                    trailingIcon = { Icon(Icons.Rounded.ChevronRight, null, tint = pal.tx2) },
                                    onClick = { sortOpen = true }
                                )
                            } else {
                                listOf("Recent", "Title", "Artist").forEachIndexed { i, n ->
                                    if (i > 0) GlassDivider()
                                    DropdownMenuItem(
                                        text = { Text(n, color = if (sort == i) Accent else pal.tx, fontSize = if (Ios27) 17.sp else 16.sp) },
                                        trailingIcon = { if (sort == i) Icon(Icons.Rounded.Check, null, tint = Accent) },
                                        onClick = { sort = i; menuOpen = false }
                                    )
                                }
                            }
                        }
                    }
                }) { i -> detail = null; pagerScope.launch { pager.animateScrollToPage(i) } }
                if (selecting && detail == null) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(Icons.Rounded.Close, pal.tx2, box = 40.dp, size = 22.dp) { selecting = false; selIds = emptySet() }
                        Text(selIds.size.toString() + " selected", color = pal.tx, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("Select all", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(RS)).clickable { selIds = allSongs.map { it.id }.toSet() }.padding(horizontal = 10.dp, vertical = 8.dp))
                        Text("Add to playlist", color = Accent.copy(alpha = if (selIds.isEmpty()) .4f else 1f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(RS)).clickable(enabled = selIds.isNotEmpty()) { dlg = 5 }.padding(horizontal = 10.dp, vertical = 8.dp))
                    }
                }
                val d = detail
                if (d != null) {
                    val title = when {
                        d.startsWith("artist:") -> d.removePrefix("artist:")
                        d.startsWith("album:") -> d.removePrefix("album:")
                        d == "pl:recent" -> "Recently Played"
                        d == "pl:fav" -> "Favourites"
                        else -> pls.firstOrNull { it.id == d.removePrefix("pl:") }?.name ?: "Playlist"
                    }
                    val canAdd = d == "pl:fav" || (d.startsWith("pl:") && d != "pl:recent")
                    val userPl = d.startsWith("pl:") && d != "pl:recent" && d != "pl:fav"
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(Icons.Rounded.ArrowBackIosNew, Accent, box = 40.dp, size = 20.dp) { detail = null }
                        Column(Modifier.weight(1f)) {
                            Text(title, color = pal.tx, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(detailSongs.size.toString() + " songs", color = pal.tx2, fontSize = 13.sp)
                        }
                        if (canAdd) Text("Add songs", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(RS)).clickable { dlg = 3 }.padding(horizontal = 10.dp, vertical = 8.dp))
                        if (userPl) Text("Delete", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(RS)).clickable { val pid = d.removePrefix("pl:"); detail = null; savePls(pls.filter { it.id != pid }) }.padding(horizontal = 10.dp, vertical = 8.dp))
                    }
                } else {
                    CountRow(pager, allSongs.size, artistRows.size, albumRows.size, hidden.size) { hidden = emptySet(); prefs.edit().putStringSet("hidden", hidden).apply() }
                }
                if (!granted) {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tunes needs access to your music to build your library. Grant it in Settings, then come back to the app.", color = pal.tx2, fontSize = 15.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Open Settings") }
                    }
                } else if (d != null) {
                    RowsList(
                        detailRows, detailState, curId, cur != null,
                        if (d.startsWith("pl:")) "Empty. Tap Add songs to fill it." else "No songs",
                        d.startsWith("pl:"),
                        { listH = it },
                        { r -> onRow(r, detailSongs) },
                        { r -> removeFromDetail(r.arg.toLong()) },
                        { r -> infoTrack = trackById[r.arg.toLong()]; editMode = false }
                    )
                } else {
                    HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), beyondBoundsPageCount = 1) { page ->
                        val rows = when (page) { 0 -> allRows; 1 -> artistRows; 2 -> albumRows; else -> plRows }
                        RowsList(
                            rows, listStates[page], curId, cur != null,
                            when (page) { 0 -> "No songs found"; 1 -> "No artists"; 2 -> "No albums"; else -> "" },
                            false,
                            { listH = it },
                            { r -> if (selecting && r.kind == 0) { val id = r.arg.toLong(); selIds = if (id in selIds) selIds - id else selIds + id } else onRow(r, allSongs) },
                            { },
                            { r -> infoTrack = trackById[r.arg.toLong()]; editMode = false },
                            if (selecting) selIds else null
                        )
                    }
                }
            }

            if (cur != null) {
                val scrim = if (Ios27) matColor(Mat.Thin, dk) else (if (dk) Color.Black.copy(alpha = .38f) else Color.White.copy(alpha = .45f))
                val miniShape = RoundedCornerShape(RC)
                Box((if (Ios27) Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp).shadow(14.dp, miniShape, ambientColor = Color.Black.copy(alpha = .25f), spotColor = Color.Black.copy(alpha = .25f)).clip(miniShape).border(0.6.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = if (dk) .30f else .9f), Color.White.copy(alpha = if (dk) .04f else .2f))), miniShape) else Modifier.align(Alignment.BottomCenter).fillMaxWidth().clipToBounds()).clickable { showPlayer = true }) {
                    if (blurOn) {
                        // see-through blur of the list behind, with only a soft hint of the song's color
                        MiniGhost(Modifier.matchParentSize(), pager, detail != null, listOf(allRows, artistRows, albumRows, plRows), detailRows, listStates, detailState, listH)
                        Box(Modifier.matchParentSize().background(scrim))
                        if (Ios27) {
                            val miniCol by coverColor(cur)
                            Box(Modifier.matchParentSize().background(miniCol.copy(alpha = if (dk) .20f else .24f)))
                        }
                    } else {
                        Box(Modifier.matchParentSize().background(pal.card))
                    }
                    Column {
                        MiniBar(ps, total, if (Ios27) Modifier.padding(horizontal = 22.dp) else Modifier)
                        Row(Modifier.fillMaxWidth().clickable { showPlayer = true }.then(if (Ios27) Modifier.padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp) else Modifier.navigationBarsPadding().padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp)), verticalAlignment = Alignment.CenterVertically) {
                            Cover(cur, Modifier.size(if (Ios27) 50.dp else 54.dp), if (Ios27) 12.dp else 8.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(cur.title, color = pal.tx, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false, modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE))
                                Text(cur.artist, color = pal.tx2, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconBtn(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, box = 52.dp, size = 32.dp) { togglePlay() }
                            IconBtn(Icons.Rounded.SkipNext, box = 52.dp, size = 32.dp) { player?.seekToNext() }
                        }
                    }
                }
            }

            val it0 = infoTrack
            if (it0 != null) {
                var et by remember(it0.id, editMode) { mutableStateOf(it0.title) }
                var ea by remember(it0.id, editMode) { mutableStateOf(it0.artist) }
                var eb by remember(it0.id, editMode) { mutableStateOf(it0.album) }
                @Composable
                fun field(label: String, value: String, onChange: (String) -> Unit) {
                    Text(label, color = pal.tx2, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    if (editMode) {
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(RS)).background(pal.fill).padding(12.dp)) {
                            BasicTextField(value, onChange, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 17.sp), cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
                        }
                    } else {
                        Text(value.ifBlank { "Unknown" }, color = pal.tx, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    }
                }
                AlertDialog(
                    onDismissRequest = { infoTrack = null; editMode = false },
                    containerColor = if (Ios27) pal.card.copy(alpha = .9f) else pal.card,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (editMode) "Edit details" else "Song info", color = pal.tx, modifier = Modifier.weight(1f))
                            if (!editMode) IconBtn(Icons.Rounded.Edit, Accent, box = 40.dp, size = 22.dp) { editMode = true }
                        }
                    },
                    text = {
                        Column {
                            field("Song", et) { et = it }
                            field("Artist", ea) { ea = it }
                            field("Album", eb) { eb = it }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (editMode) {
                                val e = Ed(et.trim().ifEmpty { it0.title }, ea.trim().ifEmpty { it0.artist }, eb.trim())
                                edits = edits + (it0.id to e)
                                prefs.edit().putString("edits", saveEdits(edits)).apply()
                            }
                            infoTrack = null; editMode = false
                        }) { Text(if (editMode) "Save" else "Close", color = Accent) }
                    },
                    dismissButton = if (editMode) ({ TextButton(onClick = { editMode = false }) { Text("Cancel", color = pal.tx2) } }) else null
                )
            }

            if (dlg == 1) {
                var name by remember { mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { dlg = 0; pendingAdd = null; pendingIds = null },
                    containerColor = if (Ios27) pal.card.copy(alpha = .9f) else pal.card,
                    title = { Text("New playlist", color = pal.tx) },
                    text = {
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(RS)).background(pal.fill).padding(12.dp)) {
                            if (name.isEmpty()) Text("Name", color = pal.tx2, fontSize = 17.sp)
                            BasicTextField(name, { name = it }, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 17.sp), cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val n = name.trim()
                            if (n.isNotEmpty()) {
                                val first = pendingAdd
                                val multi = pendingIds
                                val pl = Pl(System.currentTimeMillis().toString(), n, multi ?: (if (first != null) listOf(first.id) else emptyList()))
                                savePls(pls + pl)
                                if (first == null && multi == null) { detail = "pl:" + pl.id }
                                if (multi != null) { selecting = false; selIds = emptySet() }
                            }
                            dlg = 0; pendingAdd = null; pendingIds = null
                        }) { Text("Create", color = Accent) }
                    },
                    dismissButton = { TextButton(onClick = { dlg = 0; pendingAdd = null; pendingIds = null }) { Text("Cancel", color = pal.tx2) } }
                )
            }
            if (dlg == 2 && cur != null) {
                AlertDialog(
                    onDismissRequest = { dlg = 0 },
                    containerColor = if (Ios27) pal.card.copy(alpha = .9f) else pal.card,
                    title = { Text("Add to playlist", color = pal.tx) },
                    text = {
                        Column {
                            pls.forEach { pl ->
                                val has = cur.id in pl.ids
                                Row(Modifier.fillMaxWidth().clickable {
                                    savePls(pls.map { if (it.id == pl.id) it.copy(ids = if (has) it.ids - cur.id else it.ids + cur.id) else it })
                                }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(pl.name, color = pal.tx, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                    if (has) Icon(Icons.Rounded.Check, null, tint = Accent)
                                }
                            }
                            Text("New playlist...", color = Accent, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { pendingAdd = cur; dlg = 1 }.padding(vertical = 12.dp))
                        }
                    },
                    confirmButton = { TextButton(onClick = { dlg = 0 }) { Text("Done", color = Accent) } }
                )
            }
            if (dlg == 5) {
                AlertDialog(
                    onDismissRequest = { dlg = 0 },
                    containerColor = if (Ios27) pal.card.copy(alpha = .9f) else pal.card,
                    title = { Text("Add " + selIds.size + " songs to", color = pal.tx) },
                    text = {
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            pls.forEach { pl ->
                                Text(pl.name, color = pal.tx, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable {
                                    savePls(pls.map { if (it.id == pl.id) it.copy(ids = it.ids + selIds.filter { id -> id !in it.ids }) else it })
                                    dlg = 0; selecting = false; selIds = emptySet()
                                }.padding(vertical = 12.dp))
                            }
                            Text("New playlist...", color = Accent, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { pendingIds = selIds.toList(); dlg = 1 }.padding(vertical = 12.dp))
                        }
                    },
                    confirmButton = { TextButton(onClick = { dlg = 0 }) { Text("Cancel", color = pal.tx2) } }
                )
            }
            if (dlg == 3) {
                var pq by remember { mutableStateOf("") }
                val cand = remember(visible, pq) { visible.filter { pq.isBlank() || (it.title + " " + it.artist).contains(pq, ignoreCase = true) } }
                AlertDialog(
                    onDismissRequest = { dlg = 0 },
                    containerColor = if (Ios27) pal.card.copy(alpha = .9f) else pal.card,
                    title = { Text("Add songs", color = pal.tx) },
                    text = {
                        Column {
                            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(RS)).background(pal.fill).padding(10.dp)) {
                                if (pq.isEmpty()) Text("Search", color = pal.tx2, fontSize = 16.sp)
                                BasicTextField(pq, { pq = it }, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 16.sp), cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
                            }
                            Spacer(Modifier.height(8.dp))
                            LazyColumn(Modifier.fillMaxWidth().height(360.dp)) {
                                items(cand, key = { it.id }) { t ->
                                    val has = inDetail(t)
                                    Row(Modifier.fillMaxWidth().clickable { toggleInDetail(t) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(t.title, color = pal.tx, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(t.artist, color = pal.tx2, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        if (has) Icon(Icons.Rounded.Check, null, tint = Accent)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { dlg = 0 }) { Text("Done", color = Accent) } }
                )
            }

            AnimatedVisibility(visible = settingsPage != 0, enter = slideInHorizontally(tween(280)) { it }, exit = slideOutHorizontally(tween(240)) { it }) {
                Column(Modifier.fillMaxSize().background(pal.bg).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}.statusBarsPadding().navigationBarsPadding()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = if (Ios27) 16.dp else 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        PlayerBtn(Icons.Rounded.ArrowBackIosNew, Accent, pal.dark, classicBox = 40.dp, classicSize = 20.dp, box = 30.dp, size = 17.dp, neutralBg = true, custom = { BackChevron(Accent) }) { settingsPage = if (settingsPage >= 2) 1 else 0 }
                        if (Ios27) Spacer(Modifier.width(14.dp))
                        Text(when (settingsPage) { 2 -> "Themes"; 3 -> "About"; 4 -> "Folders"; else -> "Settings" }, color = pal.tx, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    if (settingsPage == 2) {
                        var hue by remember { mutableFloatStateOf(FloatArray(3).also { android.graphics.Color.colorToHSV(Accent.toArgb(), it) }[0]) }
                        fun setAccent(c: Color) { Accent = c; prefs.edit().putInt("accent", c.toArgb()).apply() }
                        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                            Text("Style", color = pal.tx2, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                listOf("Classic" to false, "Glossy" to true).forEach { (name, ios) ->
                                    val sel = Ios27 == ios
                                    val pv = if (ios) (if (darkTheme) IosDarkPal else IosLightPal) else (if (darkTheme) DarkPal else LightPal)
                                    Column(Modifier.weight(1f).clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).border(if (sel) 2.dp else 0.dp, if (sel) Accent else Color.Transparent, RoundedCornerShape(RC)).clickable { Ios27 = ios; prefs.edit().putBoolean("ios27", ios).apply() }.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(if (ios) 18.dp else 10.dp)).background(pv.bg)) {
                                            Box(Modifier.align(Alignment.TopCenter).padding(top = 10.dp).fillMaxWidth(.8f).height(14.dp).clip(RoundedCornerShape(if (ios) 50.dp else 5.dp)).background(pv.fill))
                                            Box(Modifier.align(Alignment.Center).fillMaxWidth(.8f).height(22.dp).clip(RoundedCornerShape(if (ios) 11.dp else 6.dp)).background(pv.card))
                                            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = if (ios) 8.dp else 0.dp).then(if (ios) Modifier.fillMaxWidth(.86f).clip(RoundedCornerShape(50.dp)) else Modifier.fillMaxWidth()).height(if (ios) 20.dp else 18.dp).background(pv.card)) {
                                                Box(Modifier.align(Alignment.CenterStart).padding(start = 8.dp).size(10.dp).clip(RoundedCornerShape(if (ios) 5.dp else 2.dp)).background(Accent))
                                            }
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (sel) { Icon(Icons.Rounded.CheckCircle, null, tint = Accent, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)) }
                                            Text(name, color = pal.tx, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(22.dp))
                            Text("Appearance", color = pal.tx2, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                            Row(Modifier.fillMaxWidth().then(if (Ios27) Modifier.clip(CircleShape).background(if (pal.dark) Color.White.copy(alpha = .05f) else Color.Black.copy(alpha = .04f)).border(1.2.dp, glassRing(pal.dark, container = true), CircleShape).padding(4.dp) else Modifier.clip(RoundedCornerShape(RC)).background(pal.card).padding(6.dp)), horizontalArrangement = Arrangement.spacedBy(if (Ios27) 0.dp else 6.dp)) {
                                listOf("System", "Light", "Dark").forEachIndexed { i, n ->
                                    val on = themeMode == i
                                    Box(Modifier.weight(1f).then(if (Ios27) (if (on) Modifier.then(if (pal.dark) Modifier else Modifier.shadow(3.dp, CircleShape)).clip(CircleShape).background(if (pal.dark) Color.White.copy(alpha = .13f) else Color.White).border(1.2.dp, glassRing(pal.dark, selected = true), CircleShape) else Modifier.clip(CircleShape)) else Modifier.clip(RoundedCornerShape(RS)).background(if (on) Accent else Color.Transparent)).clickable { themeMode = i; prefs.edit().putInt("theme", i).apply() }.padding(vertical = if (Ios27) 11.dp else 10.dp), contentAlignment = Alignment.Center) {
                                        Text(n, color = if (Ios27) (if (on) Accent else pal.tx) else (if (on) Color.White else pal.tx), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                                    }
                                }
                            }
                            Spacer(Modifier.height(22.dp))
                            Text("List size", color = pal.tx2, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("A", color = pal.tx2, fontSize = 13.sp)
                                    Slider(
                                        value = ListScale, onValueChange = { ListScale = it },
                                        onValueChangeFinished = { prefs.edit().putFloat("list_scale", ListScale).apply() },
                                        valueRange = 0.8f..1.3f, steps = 4, modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                                        colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = pal.fill)
                                    )
                                    Text("A", color = pal.tx2, fontSize = 22.sp)
                                }
                                Text((ListScale * 100).roundToInt().toString() + "%", color = pal.tx2, fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                                Spacer(Modifier.height(8.dp))
                                ListRow("Song title", "Artist name", "3:21", false, false, null)
                            }
                            Spacer(Modifier.height(22.dp))
                            Text("App color", color = pal.tx2, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                listOf(0xFFFA2D55, 0xFFFF9500, 0xFFFFCC00, 0xFF34C759, 0xFF00C7BE, 0xFF0A84FF, 0xFF5E5CE6, 0xFFBF5AF2, 0xFFFF375F, 0xFF8E8E93).chunked(5).forEach { rowColors ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        rowColors.forEach { v ->
                                            val c = Color(v)
                                            Box(Modifier.size(44.dp).clip(CircleShape).background(c).clickable { setAccent(c); val hsv = FloatArray(3); android.graphics.Color.colorToHSV(c.toArgb(), hsv); hue = hsv[0] }, contentAlignment = Alignment.Center) {
                                                if (Accent == c) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(24.dp))
                                            }
                                        }
                                    }
                                }
                                Text("Custom", color = pal.tx2, fontSize = 13.sp)
                                Slider(
                                    value = hue, onValueChange = { hue = it; setAccent(Color.hsv(it, 0.85f, 1f)) }, valueRange = 0f..360f,
                                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = pal.fill)
                                )
                            }
                            Spacer(Modifier.height(22.dp))
                            Text("Effects", color = pal.tx2, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).clickable { blurOn = !blurOn; prefs.edit().putBoolean("blur", blurOn).apply() }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Blur", color = pal.tx, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                                    Text("Blurred background behind the mini player", color = pal.tx2, fontSize = 13.sp)
                                }
                                TunesSwitch(checked = blurOn, onCheckedChange = { blurOn = it; prefs.edit().putBoolean("blur", it).apply() })
                            }
                            Spacer(Modifier.height(24.dp))
                        }
                    } else if (settingsPage == 4) {
                        val folders = remember(rawTracks) { rawTracks.filter { it.folder.isNotEmpty() }.groupBy { it.folder }.map { it.key to it.value.size }.sortedBy { it.first.lowercase() } }
                        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                            Text("Choose which folders Tunes scans for songs.", color = pal.tx2, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
                            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.End) {
                                Text("Select all", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(RS)).clickable { setExcluded(emptySet()) }.padding(horizontal = 10.dp, vertical = 8.dp))
                                Text("Deselect all", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(RS)).clickable { setExcluded(folders.map { it.first }.toSet()) }.padding(horizontal = 10.dp, vertical = 8.dp))
                            }
                            if (folders.isEmpty()) Text("No folders found yet.", color = pal.tx2, fontSize = 15.sp, modifier = Modifier.padding(4.dp))
                            folders.forEach { (path, n) ->
                                val on = path !in excluded
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).clickable { setExcluded(if (on) excluded + path else excluded - path) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Folder, null, tint = if (on) Accent else pal.tx2, modifier = Modifier.size(24.dp))
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(path.substringAfterLast('/').ifEmpty { path }, color = pal.tx, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(path.removePrefix("/storage/emulated/0/") + "  \u00B7  " + n + (if (n == 1) " song" else " songs"), color = pal.tx2, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    TunesSwitch(checked = on, onCheckedChange = { setExcluded(if (it) excluded - path else excluded + path) })
                                }
                                Spacer(Modifier.height(8.dp))
                            }
                            Spacer(Modifier.height(24.dp))
                        }
                    } else if (settingsPage == 3) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(painterResource(R.drawable.about_logo), null, Modifier.height(110.dp))
                            Spacer(Modifier.height(18.dp))
                            Text("Tunes", color = pal.tx, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(4.dp))
                            Text("\u00A9 2026 Tunes Music Collective", color = pal.tx2, fontSize = 15.sp)
                            Spacer(Modifier.height(22.dp))
                            Text("ZEDD", color = pal.tx, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(18.dp))
                            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).padding(16.dp)) {
                                Text("Tunes is a beautiful, privacy-focused open-source app that allows you to stream and organize your music library and share it seamlessly with others without data collection.", color = pal.tx2, fontSize = 15.sp, lineHeight = 21.sp)
                            }
                            Spacer(Modifier.height(32.dp))
                            Text("Core Developer", color = pal.tx, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Mo Zedd", color = pal.tx2, fontSize = 16.sp)
                        }
                    } else {
                        Row(Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).clickable { settingsPage = 2 }.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Palette, null, tint = Accent, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(14.dp))
                            Text("Themes", color = pal.tx, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            Icon(Icons.Rounded.ChevronRight, null, tint = pal.tx2, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).clickable { settingsPage = 4 }.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Folder, null, tint = Accent, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(14.dp))
                            Text("Folders", color = pal.tx, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            Icon(Icons.Rounded.ChevronRight, null, tint = pal.tx2, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(RC)).background(pal.card).rim(RoundedCornerShape(RC), pal.dark).clickable { settingsPage = 3 }.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Info, null, tint = Accent, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(14.dp))
                            Text("About", color = pal.tx, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            Icon(Icons.Rounded.ChevronRight, null, tint = pal.tx2, modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }

            val c = cur
            if (c != null) {
                AnimatedVisibility(visible = showPlayer, enter = slideInVertically(tween(320)) { it }, exit = slideOutVertically(tween(260)) { it }) {
                    val baseS = coverColor(c)
                    val bgc = if (dk) Color(0xFF0B0B14) else Color(0xFFF7F7FB)
                    val fg = if (dk) Color.White else Color(0xFF111114)
                    val fg2 = fg.copy(alpha = .6f)
                    var menu by remember { mutableStateOf(false) }
                    var queueMenu by remember { mutableStateOf(false) }
                    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
                    val maxV = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
                    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV) }
                    var volDrag by remember { mutableStateOf(false) }
                    LaunchedEffect(Unit) {
                        while (true) { if (!volDrag) vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV; delay(500) }
                    }
                    val fav = c.id.toString() in favs
                    val cfg = LocalConfiguration.current
                    val coverSize = minOf(cfg.screenWidthDp.dp - 20.dp, (cfg.screenHeightDp * 0.355f).dp)
                    val gap = (cfg.screenHeightDp * 0.027f).dp.coerceIn(14.dp, 28.dp)   // even vertical rhythm between player sections
                    val upNext = remember(qv, curId, shuffle, player, trackById) {
                        val out = ArrayList<Pair<Int, Track>>()
                        val p = player
                        if (p != null) {
                            val tl = p.currentTimeline
                            if (!tl.isEmpty) {
                                var idx = p.currentMediaItemIndex
                                var n = 0
                                while (n < 40) {
                                    idx = tl.getNextWindowIndex(idx, Player.REPEAT_MODE_OFF, p.shuffleModeEnabled)
                                    if (idx == C.INDEX_UNSET) break
                                    val t = p.getMediaItemAt(idx).mediaId.toLongOrNull()?.let { trackById[it] }
                                    if (t != null) out.add(Pair(idx, t))
                                    n++
                                }
                            }
                        }
                        out
                    }
                    val dragY = remember { Animatable(0f) }
                    val dragScope = rememberCoroutineScope()
                    val closePx = with(LocalDensity.current) { 140.dp.toPx() }
                    val dragState = rememberDraggableState { dy -> dragScope.launch { dragY.snapTo((dragY.value + dy).coerceAtLeast(0f)) } }
                    val pullDown = Modifier.draggable(
                        state = dragState,
                        orientation = Orientation.Vertical,
                        onDragStopped = { v ->
                            if (dragY.value > closePx || v > 1200f) {
                                showPlayer = false
                            } else {
                                dragY.animateTo(0f, spring(stiffness = Spring.StiffnessMediumLow))
                            }
                        }
                    )
                    Column(Modifier.fillMaxSize().offset { IntOffset(0, dragY.value.roundToInt()) }.drawBehind {
                        drawRect(vividBrush(baseS.value, bgc, dk))
                    }.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}.statusBarsPadding().navigationBarsPadding()) {
                        Box(Modifier.fillMaxWidth().height(48.dp).then(pullDown), contentAlignment = Alignment.Center) {
                            Box(Modifier.clip(RoundedCornerShape(12.dp)).clickable { showPlayer = false }.padding(horizontal = 24.dp, vertical = 14.dp)) { Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(fg2.copy(alpha = .5f))) }
                        }
                        Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center) {
                            Box(Modifier.fillMaxWidth().then(pullDown), contentAlignment = Alignment.Center) {
                                Cover(c, Modifier.size(coverSize).shadow(if (Ios27) 32.dp else 24.dp, RoundedCornerShape(if (Ios27) 28.dp else 22.dp)), if (Ios27) 28.dp else 22.dp, big = true)
                            }
                            Column(Modifier.padding(horizontal = 24.dp)) {
                                Spacer(Modifier.height(gap))
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(c.title, color = fg, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(c.artist, color = fg2, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Box {
                                        Box(Modifier.size(38.dp).then(if (Ios27) Modifier.clip(CircleShape).background(if (dk) Color.White.copy(alpha = .09f) else Color.White.copy(alpha = .55f)).border(1.2.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = if (dk) .55f else 1f), Color.White.copy(alpha = if (dk) .10f else .35f))), CircleShape) else Modifier.clip(CircleShape).background(fg.copy(alpha = .18f))).clickable { menu = true }, contentAlignment = Alignment.Center) {
                                            Icon(Icons.Rounded.MoreHoriz, null, tint = fg, modifier = Modifier.size(22.dp))
                                        }
                                        MenuTheme(scheme, baseS, bgc, dk, fg) {
                                            GlassMenu(expanded = menu, onDismissRequest = { menu = false }, classicBg = true) {
                                                Row(
                                                    Modifier.fillMaxWidth().clickable {
                                                        menu = false; showPlayer = false
                                                        pagerScope.launch { pager.scrollToPage(1) }
                                                        detail = "artist:" + c.artist
                                                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(Modifier.weight(1f)) {
                                                        Text("Artist", color = fg2, fontSize = 12.sp)
                                                        Text(c.artist, color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                                    }
                                                    Icon(Icons.Rounded.ChevronRight, null, tint = fg2, modifier = Modifier.size(20.dp))
                                                }
                                                Row(
                                                    Modifier.fillMaxWidth().clickable {
                                                        menu = false; showPlayer = false
                                                        pagerScope.launch { pager.scrollToPage(2) }
                                                        detail = "album:" + albumOf(c)
                                                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(Modifier.weight(1f)) {
                                                        Text("Album", color = fg2, fontSize = 12.sp)
                                                        Text(albumOf(c), color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                                    }
                                                    Icon(Icons.Rounded.ChevronRight, null, tint = fg2, modifier = Modifier.size(20.dp))
                                                }
                                                Box(Modifier.fillMaxWidth().padding(horizontal = if (Ios27) 16.dp else 0.dp).height(if (Ios27) 0.5.dp else 1.dp).background(fg.copy(alpha = .14f)))
                                                DropdownMenuItem(
                                                    text = { Text("Playlist", color = fg) },
                                                    leadingIcon = { Icon(Icons.Rounded.PlaylistAdd, null, tint = fg2) },
                                                    onClick = { menu = false; dlg = 2 }
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(gap))
                                PlayerSeek(ps, total, fg, { dragging = true }, { v -> player?.seekTo(v); dragging = false })
                                Spacer(Modifier.height(gap * 0.8f))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    PlayerBtn(Icons.Rounded.Shuffle, if (shuffle) fg else fg2, dk) { player?.shuffleModeEnabled = !shuffle }
                                    PlayerBtn(if (Ios27) Icons.Rounded.SkipPrevious else Icons.Rounded.FastRewind, fg, dk, 64.dp, 46.dp, 56.dp, 30.dp) { player?.seekToPrevious() }
                                    PlayerBtn(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, fg, dk, 84.dp, 62.dp, 78.dp, 40.dp) { togglePlay() }
                                    PlayerBtn(if (Ios27) Icons.Rounded.SkipNext else Icons.Rounded.FastForward, fg, dk, 64.dp, 46.dp, 56.dp, 30.dp) { player?.seekToNext() }
                                    PlayerBtn(if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, if (repeat == Player.REPEAT_MODE_OFF) fg2 else fg, dk) {
                                        player?.repeatMode = when (repeat) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                                    }
                                }
                                Spacer(Modifier.height(gap))
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.width(36.dp), contentAlignment = Alignment.CenterStart) { Icon(Icons.Rounded.VolumeDown, null, tint = fg2, modifier = Modifier.size(22.dp)) }
                                    Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                                        Bar(vol, fg, !Ios27, { f -> volDrag = true; vol = f; am.setStreamVolume(AudioManager.STREAM_MUSIC, (f * maxV).roundToInt(), 0) }, { volDrag = false }, if (Ios27) 7.dp else 5.dp)
                                    }
                                    Box(Modifier.width(42.dp), contentAlignment = Alignment.CenterEnd) { Icon(Icons.Rounded.VolumeUp, null, tint = fg2, modifier = Modifier.size(22.dp)) }
                                }
                                Row(Modifier.fillMaxWidth().padding(top = gap * 0.8f), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    PlayerBtn(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (fav) Accent else fg2, dk) { toggleFav(c) }
                                    Box {
                                        PlayerBtn(Icons.Rounded.Menu, fg2, dk) { queueMenu = true }
                                        MenuTheme(scheme, baseS, bgc, dk, fg) {
                                            GlassMenu(expanded = queueMenu, onDismissRequest = { queueMenu = false }, classicBg = true, modifier = Modifier.width(300.dp).heightIn(max = 440.dp)) {
                                                Text("Up next", color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                                                if (upNext.isEmpty()) {
                                                    Text("Nothing queued", color = fg2, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                                                }
                                                upNext.forEach { pr ->
                                                    Row(
                                                        Modifier.fillMaxWidth().clickable { player?.seekToDefaultPosition(pr.first); player?.play(); queueMenu = false }.padding(horizontal = 16.dp, vertical = 10.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(Modifier.weight(1f)) {
                                                            Text(pr.second.title, color = fg, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                            Text(pr.second.artist, color = fg2, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                        }
                                                        Spacer(Modifier.width(10.dp))
                                                        Text(fmt(pr.second.dur), color = fg2, fontSize = 13.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(24.dp))
                            }
                        }
                    }
                }
            }
        }
    }
    }
}
