package com.tunes.app

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

val Accent = Color(0xFFFA2D55)

class Pal(val bg: Color, val card: Color, val tx: Color, val tx2: Color, val fill: Color)
val LightPal = Pal(Color(0xFFF2F2F7), Color.White, Color(0xFF111114), Color(0xFF8A8A92), Color(0x1F767680))
val DarkPal = Pal(Color.Black, Color(0xFF1C1C1E), Color(0xFFF5F5F7), Color(0xFF9A9AA1), Color(0x3D767680))
val LocalPal = staticCompositionLocalOf { LightPal }

data class Track(val id: Long, val title: String, val artist: String, val album: String, val dur: Long, val uri: Uri) {
    fun item(): MediaItem = MediaItem.Builder().setMediaId(id.toString()).setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build()).build()
}

data class Pl(val id: String, val name: String, val ids: List<Long>)

fun loadPls(s: String?): List<Pl> = try {
    if (s == null) emptyList() else {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val ia = o.getJSONArray("ids")
            Pl(o.getString("id"), o.getString("name"), (0 until ia.length()).map { ia.getLong(it) })
        }
    }
} catch (e: Exception) { emptyList() }

fun fmt(ms: Long): String { val s = (ms.coerceAtLeast(0) / 1000).toInt(); return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }

fun loadTracks(c: Context): List<Track> {
    val out = ArrayList<Track>()
    val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION)
    val sel = "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND ${MediaStore.Audio.Media.DURATION}>=30000"
    c.contentResolver.query(m, proj, sel, null, "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { q ->
        while (q.moveToNext()) {
            val id = q.getLong(0)
            val artist = q.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown Artist"
            out.add(Track(id, q.getString(1) ?: "Untitled", artist, q.getString(3) ?: "", q.getLong(4), ContentUris.withAppendedId(m, id)))
        }
    }
    return out
}

object ArtCache {
    private val small = LruCache<Long, Bitmap>(400)
    private val large = LruCache<Long, Bitmap>(4)
    private val none = java.util.Collections.synchronizedSet(HashSet<Long>())
    private val sem = Semaphore(3)
    private fun cacheFor(big: Boolean) = if (big) large else small
    fun peek(id: Long, big: Boolean): ImageBitmap? = cacheFor(big).get(id)?.asImageBitmap()
    suspend fun loadAsync(c: Context, t: Track, big: Boolean): ImageBitmap? =
        sem.withPermit { withContext(Dispatchers.IO) { load(c, t, big) } }
    private fun load(c: Context, t: Track, big: Boolean): ImageBitmap? {
        val cache = cacheFor(big)
        cache.get(t.id)?.let { return it.asImageBitmap() }
        if (t.id in none) return null
        val maxPx = if (big) 900 else 200
        var bm: Bitmap? = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(c, t.uri)
            val b = r.embeddedPicture
            if (b != null) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(b, 0, b.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= maxPx) s *= 2
                bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            }
        } catch (e: Exception) {
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
        if (bm == null && Build.VERSION.SDK_INT >= 29) {
            try { bm = c.contentResolver.loadThumbnail(t.uri, Size(maxPx, maxPx), null) } catch (e: Exception) {}
        }
        if (bm == null) { none.add(t.id); return null }
        cache.put(t.id, bm)
        return bm.asImageBitmap()
    }
}

class PosState { var ms by mutableLongStateOf(0L) }

fun grad(id: Long): Brush {
    val h = ((id * 47) % 360).toFloat()
    return Brush.linearGradient(listOf(Color.hsv(h, .65f, .92f), Color.hsv((h + 50f) % 360f, .75f, .72f)))
}

@Composable
fun Cover(t: Track?, modifier: Modifier, radius: Dp = 9.dp, big: Boolean = false) {
    val ctx = LocalContext.current
    var bmp by remember(t?.id, big) { mutableStateOf(t?.let { ArtCache.peek(it.id, big) ?: ArtCache.peek(it.id, false) }) }
    LaunchedEffect(t?.id, big) {
        if (t != null && ArtCache.peek(t.id, big) == null) {
            if (!big) delay(100)
            val r = ArtCache.loadAsync(ctx, t, big)
            if (r != null) bmp = r
        }
    }
    val b = bmp
    Box(modifier.clip(RoundedCornerShape(radius)).background(grad(t?.id ?: 0L)), contentAlignment = Alignment.Center) {
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.fillMaxSize(.4f))
    }
}

@Composable
fun MiniBar(ps: PosState, total: Long, modifier: Modifier) {
    val frac = if (total > 0) (ps.ms.toFloat() / total).coerceIn(0f, 1f) else 0f
    Box(modifier.fillMaxWidth(frac).height(2.dp).background(Accent))
}

@Composable
fun SeekBar(ps: PosState, total: Long, onDrag: () -> Unit, onDone: (Long) -> Unit) {
    val p = LocalPal.current
    val max = maxOf(total, 1L).toFloat()
    Column {
        Slider(
            value = ps.ms.toFloat().coerceIn(0f, max),
            onValueChange = { onDrag(); ps.ms = it.toLong() },
            onValueChangeFinished = { onDone(ps.ms) },
            valueRange = 0f..max,
            colors = SliderDefaults.colors(thumbColor = p.tx, activeTrackColor = p.tx, inactiveTrackColor = p.fill)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(ps.ms), color = p.tx2, fontSize = 12.sp)
            Text(fmt(total), color = p.tx2, fontSize = 12.sp)
        }
    }
}

@Composable
fun IconBtn(icon: ImageVector, tint: Color? = null, box: Dp = 44.dp, size: Dp = 26.dp, onClick: () -> Unit) {
    Box(Modifier.size(box).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint ?: LocalPal.current.tx, modifier = Modifier.size(size))
    }
}

@Composable
fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(Modifier.clip(RoundedCornerShape(18.dp)).background(if (on) Accent else p.fill).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)) {
        Text(label, color = if (on) Color.White else p.tx, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TrackRow(t: Track, on: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(p.card).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Cover(t, Modifier.size(52.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, color = if (on) Accent else p.tx, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist, color = p.tx2, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(fmt(t.dur), color = p.tx2, fontSize = 14.sp)
    }
}

fun audioPerm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
fun hasAudioPerm(c: Context) = ContextCompat.checkSelfPermission(c, audioPerm()) == PackageManager.PERMISSION_GRANTED

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { TunesApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TunesApp() {
    val ctx = LocalContext.current
    val pal = if (isSystemInDarkTheme()) DarkPal else LightPal
    val prefs = remember { ctx.getSharedPreferences("tunes", Context.MODE_PRIVATE) }

    var granted by remember { mutableStateOf(hasAudioPerm(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasAudioPerm(ctx) }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm(), Manifest.permission.POST_NOTIFICATIONS) else arrayOf(audioPerm()))
    }
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var scanKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(granted, scanKey) { if (granted) tracks = withContext(Dispatchers.IO) { loadTracks(ctx) } }

    var player by remember { mutableStateOf<Player?>(null) }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        f.addListener({ try { player = f.get() } catch (e: Exception) {} }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f) }
    }
    var curId by remember { mutableStateOf<Long?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var speed by remember { mutableFloatStateOf(1f) }
    var durMs by remember { mutableLongStateOf(0L) }
    val ps = remember { PosState() }
    var dragging by remember { mutableStateOf(false) }
    DisposableEffect(player) {
        val p = player
        if (p == null) {
            onDispose { }
        } else {
            fun sync() {
                curId = p.currentMediaItem?.mediaId?.toLongOrNull()
                isPlaying = p.isPlaying
                shuffle = p.shuffleModeEnabled
                repeat = p.repeatMode
                speed = p.playbackParameters.speed
                durMs = p.duration.coerceAtLeast(0L)
            }
            val l = object : Player.Listener { override fun onEvents(pl: Player, events: Player.Events) { sync() } }
            p.addListener(l); sync()
            onDispose { p.removeListener(l) }
        }
    }
    LaunchedEffect(player) {
        val p = player ?: return@LaunchedEffect
        while (true) { if (!dragging) ps.ms = p.currentPosition; delay(400) }
    }

    var query by remember { mutableStateOf("") }
    var view by remember { mutableStateOf("all") }
    var sort by remember { mutableIntStateOf(0) }
    var favs by remember { mutableStateOf(prefs.getStringSet("fav", emptySet())!!.toSet()) }
    var hidden by remember { mutableStateOf(prefs.getStringSet("hidden", emptySet())!!.toSet()) }
    var pls by remember { mutableStateOf(loadPls(prefs.getString("pls", null))) }
    var dlg by remember { mutableIntStateOf(0) }
    var pendingAdd by remember { mutableStateOf<Track?>(null) }
    var showPlayer by remember { mutableStateOf(false) }
    val shown = remember(tracks, hidden, query, view, sort, favs, pls) {
        var l: List<Track> = when (view) {
            "all" -> tracks.filter { it.id.toString() !in hidden }
            "fav" -> tracks.filter { it.id.toString() in favs }
            else -> {
                val ids = pls.firstOrNull { it.id == view }?.ids ?: emptyList()
                ids.mapNotNull { id -> tracks.firstOrNull { it.id == id } }
            }
        }
        if (query.isNotBlank()) l = l.filter { (it.title + " " + it.artist + " " + it.album).contains(query, ignoreCase = true) }
        when (sort) {
            1 -> l.sortedBy { it.title.lowercase() }
            2 -> l.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
            else -> l
        }
    }
    val cur = tracks.firstOrNull { it.id == curId }
    BackHandler(enabled = showPlayer) { showPlayer = false }
    val total = if (durMs > 0) durMs else (cur?.dur ?: 0L)

    fun playFrom(i: Int) {
        val p = player ?: return
        p.setMediaItems(shown.map { it.item() }, i, 0L); p.prepare(); p.play()
    }
    fun toggleFav(t: Track) {
        val k = t.id.toString()
        favs = if (k in favs) favs - k else favs + k
        prefs.edit().putStringSet("fav", favs).apply()
    }
    fun togglePlay() { val p = player ?: return; if (p.isPlaying) p.pause() else p.play() }
    fun savePls(l: List<Pl>) {
        pls = l
        val a = JSONArray()
        l.forEach { p -> a.put(JSONObject().put("id", p.id).put("name", p.name).put("ids", JSONArray(p.ids))) }
        prefs.edit().putString("pls", a.toString()).apply()
    }
    fun removeTrack(t: Track) {
        when (view) {
            "all" -> { hidden = hidden + t.id.toString(); prefs.edit().putStringSet("hidden", hidden).apply() }
            "fav" -> toggleFav(t)
            else -> savePls(pls.map { if (it.id == view) it.copy(ids = it.ids - t.id) else it })
        }
    }

    CompositionLocalProvider(LocalPal provides pal) {
        Box(Modifier.fillMaxSize().background(pal.bg)) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 10.dp, top = 10.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Library", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = pal.tx, modifier = Modifier.weight(1f))
                    IconBtn(Icons.Rounded.Refresh, Accent) { granted = hasAudioPerm(ctx); scanKey++ }
                }
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().height(38.dp).clip(RoundedCornerShape(11.dp)).background(pal.fill).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Search, null, tint = pal.tx2, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Search", color = pal.tx2, fontSize = 17.sp)
                        BasicTextField(query, { query = it }, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 17.sp), cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("All", view == "all") { view = "all" }
                    Chip("Favorites", view == "fav") { view = "fav" }
                    pls.forEach { pl -> Chip(pl.name, view == pl.id) { view = pl.id } }
                    Chip("+ New", false) { pendingAdd = null; dlg = 1 }
                    Chip(listOf("Sort: Recent", "Sort: Title", "Sort: Artist")[sort], false) { sort = (sort + 1) % 3 }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${shown.size} songs", color = pal.tx2, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    if (view != "all" && view != "fav") {
                        Text("Delete playlist", color = Accent, fontSize = 13.sp, modifier = Modifier.clickable { val id = view; view = "all"; savePls(pls.filter { it.id != id }) }.padding(vertical = 6.dp))
                    } else if (view == "all" && hidden.isNotEmpty()) {
                        Text("Restore ${hidden.size} removed", color = Accent, fontSize = 13.sp, modifier = Modifier.clickable { hidden = emptySet(); prefs.edit().putStringSet("hidden", hidden).apply() }.padding(vertical = 6.dp))
                    }
                }
                if (!granted) {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tunes needs access to your music to build your library. Grant it in Settings, then tap refresh.", color = pal.tx2, fontSize = 15.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Open Settings") }
                    }
                } else if (shown.isEmpty()) {
                    Text(when (view) { "all" -> "No songs found"; "fav" -> "No favorites yet"; else -> "Empty playlist. Add songs from the player." }, color = pal.tx2, fontSize = 15.sp, modifier = Modifier.fillMaxWidth().padding(36.dp))
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = if (cur != null) 100.dp else 24.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        itemsIndexed(shown, key = { _, t -> t.id }) { i, t ->
                            val st = rememberSwipeToDismissBoxState(confirmValueChange = { v ->
                                if (v == SwipeToDismissBoxValue.EndToStart) { removeTrack(t); true } else false
                            })
                            SwipeToDismissBox(st, enableDismissFromStartToEnd = false, backgroundContent = {
                                Box(Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)).background(Color(0xFFFF3B30)).padding(end = 24.dp), contentAlignment = Alignment.CenterEnd) {
                                    Icon(Icons.Rounded.Delete, null, tint = Color.White)
                                }
                            }) { TrackRow(t, t.id == curId) { playFrom(i) } }
                        }
                    }
                }
            }

            if (cur != null) {
                Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 10.dp, vertical = 10.dp).fillMaxWidth().height(62.dp).shadow(8.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(pal.card).clickable { showPlayer = true }) {
                    Row(Modifier.fillMaxSize().padding(start = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Cover(cur, Modifier.size(46.dp), 8.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(cur.title, color = pal.tx, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(cur.artist, color = pal.tx2, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconBtn(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow) { togglePlay() }
                        IconBtn(Icons.Rounded.SkipNext) { player?.seekToNext() }
                    }
                    MiniBar(ps, total, Modifier.align(Alignment.BottomStart))
                }
            }

            if (dlg == 1) {
                var name by remember { mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { dlg = 0; pendingAdd = null },
                    containerColor = pal.card,
                    title = { Text("New playlist", color = pal.tx) },
                    text = {
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.fill).padding(12.dp)) {
                            if (name.isEmpty()) Text("Name", color = pal.tx2, fontSize = 17.sp)
                            BasicTextField(name, { name = it }, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 17.sp), cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val n = name.trim()
                            if (n.isNotEmpty()) {
                                val first = pendingAdd
                                val pl = Pl(System.currentTimeMillis().toString(), n, if (first != null) listOf(first.id) else emptyList())
                                savePls(pls + pl)
                                if (first == null) view = pl.id
                            }
                            dlg = 0; pendingAdd = null
                        }) { Text("Create", color = Accent) }
                    },
                    dismissButton = { TextButton(onClick = { dlg = 0; pendingAdd = null }) { Text("Cancel", color = pal.tx2) } }
                )
            }
            if (dlg == 2 && cur != null) {
                AlertDialog(
                    onDismissRequest = { dlg = 0 },
                    containerColor = pal.card,
                    title = { Text("Add to playlist", color = pal.tx) },
                    text = {
                        Column {
                            pls.forEach { pl ->
                                val has = cur.id in pl.ids
                                Row(Modifier.fillMaxWidth().clickable {
                                    savePls(pls.map { if (it.id == pl.id) it.copy(ids = if (has) it.ids - cur.id else it.ids + cur.id) else it })
                                }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(pl.name, color = pal.tx, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                    if (has) Icon(Icons.Rounded.Check, null, tint = Accent)
                                }
                            }
                            Text("New playlist...", color = Accent, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { pendingAdd = cur; dlg = 1 }.padding(vertical = 12.dp))
                        }
                    },
                    confirmButton = { TextButton(onClick = { dlg = 0 }) { Text("Done", color = Accent) } }
                )
            }

            val c = cur
            if (c != null) {
                AnimatedVisibility(visible = showPlayer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
                    Column(Modifier.fillMaxSize().background(pal.bg).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}.statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp)) {
                        Box(Modifier.fillMaxWidth().height(56.dp).pointerInput(Unit) {
                            var acc = 0f
                            detectVerticalDragGestures(onDragStart = { acc = 0f }, onDragEnd = { if (acc > 120f) showPlayer = false }) { _, d -> acc += d }
                        }, contentAlignment = Alignment.Center) {
                            Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(pal.tx2.copy(alpha = .5f)))
                            Box(Modifier.align(Alignment.CenterStart)) { IconBtn(Icons.Rounded.KeyboardArrowDown, size = 32.dp) { showPlayer = false } }
                        }
                        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            val sz = minOf(maxWidth * 0.92f, maxHeight)
                            Cover(c, Modifier.size(sz), 18.dp, big = true)
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.title, color = pal.tx, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(c.artist, color = pal.tx2, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            val fav = c.id.toString() in favs
                            IconBtn(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (fav) Accent else pal.tx2) { toggleFav(c) }
                        }
                        SeekBar(ps, total, { dragging = true }, { v -> player?.seekTo(v); dragging = false })
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            IconBtn(Icons.Rounded.SkipPrevious, box = 64.dp, size = 40.dp) { player?.seekToPrevious() }
                            IconBtn(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, box = 80.dp, size = 56.dp) { togglePlay() }
                            IconBtn(Icons.Rounded.SkipNext, box = 64.dp, size = 40.dp) { player?.seekToNext() }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            IconBtn(Icons.Rounded.Shuffle, if (shuffle) Accent else pal.tx2) { player?.shuffleModeEnabled = !shuffle }
                            IconBtn(if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, if (repeat == Player.REPEAT_MODE_OFF) pal.tx2 else Accent) {
                                player?.repeatMode = when (repeat) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.align(Alignment.CenterHorizontally), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
                            Chip("Speed ${speed}x", speed != 1f) {
                                val n = speeds[(speeds.indexOfFirst { it == speed }.let { if (it < 0) 1 else it } + 1) % speeds.size]
                                player?.setPlaybackSpeed(n)
                            }
                            Chip("Add to playlist", false) { dlg = 2 }
                        }
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}
