package com.tunes.app

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

val Accent = Color(0xFFFA2D55)

class Pal(val bg: Color, val card: Color, val tx: Color, val tx2: Color, val fill: Color)
val LightPal = Pal(Color(0xFFF2F2F7), Color.White, Color(0xFF111114), Color(0xFF8A8A92), Color(0x1F767680))
val DarkPal = Pal(Color.Black, Color(0xFF141416), Color(0xFFF5F5F7), Color(0xFF9A9AA1), Color(0x3D767680))
val LocalPal = staticCompositionLocalOf { LightPal }

data class Track(val id: Long, val title: String, val artist: String, val album: String, val dur: Long, val uri: Uri) {
    fun item(): MediaItem = MediaItem.Builder().setMediaId(id.toString()).setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build()).build()
}

data class Pl(val id: String, val name: String, val ids: List<Long>)

fun loadPls(s: String?): List<Pl> = try {
    if (s == null) emptyList() else {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val ia = o.getJSONArray("ids")
            Pl(o.getString("id"), o.getString("name"), (0 until ia.length()).map { ia.getLong(it) })
        }
    }
} catch (e: Exception) { emptyList() }

fun fmt(ms: Long): String { val s = (ms.coerceAtLeast(0) / 1000).toInt(); return "${s / 60}:${(s % 60).toString().padStart(2, '0')}" }

object Boot { @Volatile var ready = false }

fun readTrackCache(c: Context): List<Track> = try {
    val f = java.io.File(c.filesDir, "tracks.json")
    if (!f.exists()) emptyList() else {
        val a = JSONArray(f.readText())
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val id = o.getLong("i")
            Track(id, o.getString("t"), o.getString("a"), o.getString("b"), o.getLong("d"), ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id))
        }
    }
} catch (e: Exception) { emptyList() }

fun writeTrackCache(c: Context, l: List<Track>) {
    try {
        val a = JSONArray()
        l.forEach { t -> a.put(JSONObject().put("i", t.id).put("t", t.title).put("a", t.artist).put("b", t.album).put("d", t.dur)) }
        java.io.File(c.filesDir, "tracks.json").writeText(a.toString())
    } catch (e: Exception) {}
}

fun loadTracks(c: Context): List<Track> {
    val out = ArrayList<Track>()
    val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION)
    val sel = "${MediaStore.Audio.Media.IS_MUSIC}!=0 AND ${MediaStore.Audio.Media.DURATION}>=30000"
    c.contentResolver.query(m, proj, sel, null, "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { q ->
        while (q.moveToNext()) {
            val id = q.getLong(0)
            val artist = q.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown Artist"
            out.add(Track(id, q.getString(1) ?: "Untitled", artist, q.getString(3) ?: "", q.getLong(4), ContentUris.withAppendedId(m, id)))
        }
    }
    return out
}

object ArtCache {
    private val small = object : LruCache<Long, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }
    private val large = LruCache<Long, Bitmap>(4)
    private val none = java.util.Collections.synchronizedSet(HashSet<Long>())
    private val sem = Semaphore(3)
    private fun cacheFor(big: Boolean) = if (big) large else small
    fun peek(id: Long, big: Boolean): ImageBitmap? = cacheFor(big).get(id)?.asImageBitmap()
    suspend fun loadAsync(c: Context, t: Track, big: Boolean): ImageBitmap? =
        sem.withPermit { withContext(Dispatchers.IO) { load(c, t, big) } }
    private fun artFile(c: Context, id: Long, ext: String) = java.io.File(java.io.File(c.cacheDir, "art"), "$id.$ext")
    private fun load(c: Context, t: Track, big: Boolean): ImageBitmap? {
        val cache = cacheFor(big)
        cache.get(t.id)?.let { return it.asImageBitmap() }
        if (t.id in none) return null
        if (!big) {
            val f = artFile(c, t.id, "jpg")
            if (f.exists()) {
                val d = BitmapFactory.decodeFile(f.path)
                if (d != null) { cache.put(t.id, d); return d.asImageBitmap() }
            }
            if (artFile(c, t.id, "none").exists()) { none.add(t.id); return null }
        }
        val maxPx = if (big) 900 else 256
        var bm: Bitmap? = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(c, t.uri)
            val b = r.embeddedPicture
            if (b != null) {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(b, 0, b.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= maxPx) s *= 2
                bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            }
        } catch (e: Exception) {
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
        if (bm == null && Build.VERSION.SDK_INT >= 29) {
            try { bm = c.contentResolver.loadThumbnail(t.uri, Size(maxPx, maxPx), null) } catch (e: Exception) {}
        }
        var out: Bitmap = bm ?: run {
            none.add(t.id)
            if (!big) {
                try { val m = artFile(c, t.id, "none"); m.parentFile?.mkdirs(); m.createNewFile() } catch (e: Exception) {}
            }
            return null
        }
        if (!big && out.width > 200) {
            val h = (out.height * 200f / out.width).toInt().coerceAtLeast(1)
            out = Bitmap.createScaledBitmap(out, 200, h, true)
        }
        cache.put(t.id, out)
        if (!big) {
            try {
                val f = artFile(c, t.id, "jpg")
                f.parentFile?.mkdirs()
                java.io.FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            } catch (e: Exception) {}
        }
        return out.asImageBitmap()
    }
}

class PosState { var ms by mutableLongStateOf(0L) }

fun grad(id: Long): Brush {
    val h = ((id * 47) % 360).toFloat()
    return Brush.linearGradient(listOf(Color.hsv(h, .65f, .92f), Color.hsv((h + 50f) % 360f, .75f, .72f)))
}

@Composable
fun Cover(t: Track?, modifier: Modifier, radius: Dp = 9.dp, big: Boolean = false) {
    val ctx = LocalContext.current
    var bmp by remember(t?.id, big) { mutableStateOf(t?.let { ArtCache.peek(it.id, big) ?: ArtCache.peek(it.id, false) }) }
    LaunchedEffect(t?.id, big) {
        if (t != null && ArtCache.peek(t.id, big) == null) {
            if (!big) delay(100)
            val r = ArtCache.loadAsync(ctx, t, big)
            if (r != null) bmp = r
        }
    }
    val b = bmp
    Box(modifier.clip(RoundedCornerShape(radius)).background(grad(t?.id ?: 0L)), contentAlignment = Alignment.Center) {
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.fillMaxSize(.4f))
    }
}

@Composable
fun MiniBar(ps: PosState, total: Long, modifier: Modifier) {
    val frac = if (total > 0) (ps.ms.toFloat() / total).coerceIn(0f, 1f) else 0f
    Box(modifier.fillMaxWidth(frac).height(2.dp).background(Accent))
}

@Composable
fun Bar(frac: Float, fg: Color, thumb: Boolean, onChange: (Float) -> Unit, onDone: () -> Unit) {
    var w by remember { mutableFloatStateOf(1f) }
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    val f = frac.coerceIn(0f, 1f)
    val density = LocalDensity.current
    Box(
        Modifier.fillMaxWidth().height(28.dp)
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { o -> change((o.x / w).coerceIn(0f, 1f)); done() } }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> change((o.x / w).coerceIn(0f, 1f)) },
                    onDragEnd = { done() },
                    onDragCancel = { done() },
                    onHorizontalDrag = { ch, _ -> change((ch.position.x / w).coerceIn(0f, 1f)) }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(fg.copy(alpha = .25f)))
        Box(Modifier.fillMaxWidth(f).height(4.dp).clip(CircleShape).background(fg))
        if (thumb) {
            val half = with(density) { 7.dp.toPx() }
            Box(Modifier.offset { IntOffset((f * w - half).roundToInt(), 0) }.size(14.dp).clip(CircleShape).background(fg))
        }
    }
}

@Composable
fun PlayerSeek(ps: PosState, total: Long, fg: Color, onDrag: () -> Unit, onDone: (Long) -> Unit) {
    val frac = if (total > 0) ps.ms.toFloat() / total else 0f
    Column {
        Bar(frac, fg, true, { f -> onDrag(); ps.ms = (f * total).toLong() }, { onDone(ps.ms) })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(ps.ms), color = fg.copy(alpha = .6f), fontSize = 13.sp)
            Text("-" + fmt(total - ps.ms), color = fg.copy(alpha = .6f), fontSize = 13.sp)
        }
    }
}

@Composable
fun coverColor(t: Track): Color {
    val ctx = LocalContext.current
    val fb = remember(t.id) { Color.hsv(((t.id * 47) % 360).toFloat(), .6f, .55f) }
    var col by remember(t.id) { mutableStateOf(fb) }
    LaunchedEffect(t.id) {
        val avg = withContext(Dispatchers.IO) {
            try {
                val img = ArtCache.peek(t.id, false) ?: ArtCache.loadAsync(ctx, t, false)
                if (img == null) null else {
                    val b = Bitmap.createScaledBitmap(img.asAndroidBitmap(), 8, 8, true)
                    var r = 0; var g = 0; var bl = 0
                    for (x in 0 until 8) for (y in 0 until 8) {
                        val px = b.getPixel(x, y)
                        r += android.graphics.Color.red(px); g += android.graphics.Color.green(px); bl += android.graphics.Color.blue(px)
                    }
                    Color(r / 64, g / 64, bl / 64)
                }
            } catch (e: Exception) { null }
        }
        if (avg != null) col = avg
    }
    return animateColorAsState(col, tween(500), label = "cover").value
}

@Composable
fun IconBtn(icon: ImageVector, tint: Color? = null, box: Dp = 44.dp, size: Dp = 26.dp, onClick: () -> Unit) {
    Box(Modifier.size(box).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint ?: LocalPal.current.tx, modifier = Modifier.size(size))
    }
}

@Composable
fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(Modifier.clip(RoundedCornerShape(18.dp)).background(if (on) Accent else p.fill).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(label, color = if (on) Color.White else p.tx, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TrackRow(t: Track, on: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.card).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(t.title, color = if (on) Accent else p.tx, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist, color = p.tx2, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(12.dp))
        Text(fmt(t.dur), color = p.tx2, fontSize = 15.sp)
    }
}

@Composable
fun GhostRow(t: Track) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.card).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(t.title, color = p.tx, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist, color = p.tx2, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(12.dp))
        Text(fmt(t.dur), color = p.tx2, fontSize = 15.sp)
    }
}

fun audioPerm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
fun hasAudioPerm(c: Context) = ContextCompat.checkSelfPermission(c, audioPerm()) == PackageManager.PERMISSION_GRANTED

class RowItem(val key: String, val title: String, val sub: String, val trail: String, val kind: Int, val arg: String, val idx: Int)

@Composable
fun ListRow(title: String, sub: String, trail: String, hi: Boolean, chevron: Boolean, onClick: (() -> Unit)?, onRemove: (() -> Unit)? = null) {
    val p = LocalPal.current
    val base = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.card)
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Row(m.padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = if (hi) Accent else p.tx, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, color = p.tx2, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (trail.isNotEmpty()) { Spacer(Modifier.width(12.dp)); Text(trail, color = p.tx2, fontSize = 15.sp) }
        if (chevron) Icon(Icons.Rounded.ChevronRight, null, tint = p.tx2, modifier = Modifier.size(22.dp))
        if (onRemove != null) { Spacer(Modifier.width(4.dp)); IconBtn(Icons.Rounded.Close, p.tx2, box = 36.dp, size = 20.dp, onClick = onRemove) }
    }
}

@Composable
fun RowsList(rows: List<RowItem>, state: LazyListState, curId: Long?, miniOn: Boolean, empty: String, removable: Boolean, onSize: (Int) -> Unit, onRow: (RowItem) -> Unit, onRemove: (RowItem) -> Unit) {
    val p = LocalPal.current
    val curKey = curId?.toString()
    if (rows.isEmpty()) {
        Text(empty, color = p.tx2, fontSize = 15.sp, modifier = Modifier.fillMaxWidth().padding(36.dp))
    } else {
        LazyColumn(
            Modifier.fillMaxSize().onSizeChanged { onSize(it.height) },
            state = state,
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = if (miniOn) 130.dp else 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(rows, key = { it.key }) { r ->
                ListRow(
                    r.title, r.sub, r.trail,
                    (r.kind == 0 && r.arg == curKey) || r.kind == 4,
                    r.kind in 1..3,
                    { onRow(r) },
                    if (removable && r.kind == 0) ({ onRemove(r) }) else null
                )
            }
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun TabChips(pager: PagerState, showSort: Boolean, sort: Int, onSort: () -> Unit, onTab: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("All", "Artists", "Albums", "Playlists").forEachIndexed { i, label ->
            Chip(label, pager.currentPage == i) { onTab(i) }
        }
        if (showSort && pager.currentPage == 0) {
            Chip(listOf("Sort: Recent", "Sort: Title", "Sort: Artist")[sort], false, onSort)
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun CountRow(pager: PagerState, songs: Int, artists: Int, albums: Int, hiddenCount: Int, onRestore: () -> Unit) {
    val p = LocalPal.current
    val pg = pager.currentPage
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            when (pg) { 0 -> "$songs songs"; 1 -> "$artists artists"; 2 -> "$albums albums"; else -> "Playlists" },
            color = p.tx2, fontSize = 13.sp, modifier = Modifier.weight(1f)
        )
        if (pg == 0 && hiddenCount > 0) {
            Text("Restore $hiddenCount removed", color = Accent, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onRestore).padding(vertical = 6.dp))
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun MiniGhost(modifier: Modifier, pager: PagerState, inDetail: Boolean, rowsByPage: List<List<RowItem>>, detailRows: List<RowItem>, listStates: List<LazyListState>, detailState: LazyListState, listH: Int) {
    if (listH > 0) {
        val density = LocalDensity.current
        val rows = if (inDetail) detailRows else rowsByPage[pager.currentPage]
        val st = if (inDetail) detailState else listStates[pager.currentPage]
        val ghostState = rememberLazyListState()
        LaunchedEffect(st) {
            snapshotFlow { st.firstVisibleItemIndex to st.firstVisibleItemScrollOffset }
                .collect { (i, o) -> ghostState.scrollToItem(i, o) }
        }
        Box(modifier.clipToBounds().blur(22.dp)) {
            LazyColumn(
                Modifier.fillMaxWidth().requiredHeight(with(density) { listH.toDp() }).align(Alignment.BottomStart),
                state = ghostState,
                userScrollEnabled = false,
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 130.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) { items(rows, key = { it.key }) { r -> ListRow(r.title, r.sub, r.trail, false, r.kind in 1..3, null) } }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !Boot.ready }
        Handler(Looper.getMainLooper()).postDelayed({ Boot.ready = true }, 1200)
        enableEdgeToEdge()
        try {
            @Suppress("DEPRECATION")
            val disp = windowManager.defaultDisplay
            val curMode = disp.mode
            val best = disp.supportedModes
                .filter { it.physicalWidth == curMode.physicalWidth && it.physicalHeight == curMode.physicalHeight }
                .maxByOrNull { it.refreshRate }
            if (best != null) {
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                lp.preferredRefreshRate = best.refreshRate
                window.attributes = lp
            }
        } catch (e: Exception) {
        }
        setContent { TunesApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TunesApp() {
    val ctx = LocalContext.current
    val pal = if (isSystemInDarkTheme()) DarkPal else LightPal
    val prefs = remember { ctx.getSharedPreferences("tunes", Context.MODE_PRIVATE) }

    var granted by remember { mutableStateOf(hasAudioPerm(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasAudioPerm(ctx) }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm(), Manifest.permission.POST_NOTIFICATIONS) else arrayOf(audioPerm()))
    }
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var scanKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        val cached = withContext(Dispatchers.IO) { readTrackCache(ctx) }
        if (tracks.isEmpty()) tracks = cached
        Boot.ready = true
    }
    LaunchedEffect(granted, scanKey) {
        if (granted) {
            val fresh = withContext(Dispatchers.IO) { loadTracks(ctx) }
            if (fresh != tracks) {
                tracks = fresh
                withContext(Dispatchers.IO) { writeTrackCache(ctx, fresh) }
            }
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = object : LifecycleEventObserver {
            override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
                if (event == Lifecycle.Event.ON_RESUME) { granted = hasAudioPerm(ctx); scanKey++ }
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    var player by remember { mutableStateOf<Player?>(null) }
    DisposableEffect(Unit) {
        val f = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        f.addListener({ try { player = f.get() } catch (e: Exception) {} }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(f) }
    }
    var curId by remember { mutableStateOf<Long?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var speed by remember { mutableFloatStateOf(1f) }
    var durMs by remember { mutableLongStateOf(0L) }
    val ps = remember { PosState() }
    var dragging by remember { mutableStateOf(false) }
    var qv by remember { mutableIntStateOf(0) }
    DisposableEffect(player) {
        val p = player
        if (p == null) {
            onDispose { }
        } else {
            fun sync() {
                curId = p.currentMediaItem?.mediaId?.toLongOrNull()
                isPlaying = p.isPlaying
                shuffle = p.shuffleModeEnabled
                repeat = p.repeatMode
                speed = p.playbackParameters.speed
                durMs = p.duration.coerceAtLeast(0L)
                qv++
            }
            val l = object : Player.Listener { override fun onEvents(pl: Player, events: Player.Events) { sync() } }
            p.addListener(l); sync()
            onDispose { p.removeListener(l) }
        }
    }
    LaunchedEffect(player) {
        val p = player ?: return@LaunchedEffect
        while (true) { if (!dragging) ps.ms = p.currentPosition; delay(400) }
    }

    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(0) }
    var favs by remember { mutableStateOf(prefs.getStringSet("fav", emptySet())!!.toSet()) }
    var hidden by remember { mutableStateOf(prefs.getStringSet("hidden", emptySet())!!.toSet()) }
    var pls by remember { mutableStateOf(loadPls(prefs.getString("pls", null))) }
    var recent by remember { mutableStateOf((prefs.getString("recent", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }) }
    var dlg by remember { mutableIntStateOf(0) }
    var pendingAdd by remember { mutableStateOf<Track?>(null) }
    var detail by remember { mutableStateOf<String?>(null) }
    var showPlayer by remember { mutableStateOf(false) }
    val pager = rememberPagerState { 4 }
    val pagerScope = rememberCoroutineScope()
    val ls0 = rememberLazyListState()
    val ls1 = rememberLazyListState()
    val ls2 = rememberLazyListState()
    val ls3 = rememberLazyListState()
    val listStates = listOf(ls0, ls1, ls2, ls3)
    val detailState = rememberLazyListState()
    var listH by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val q = query.trim()
    LaunchedEffect(detail) { detailState.scrollToItem(0) }

    LaunchedEffect(curId) {
        val id = curId
        if (id != null && recent.firstOrNull() != id) {
            recent = (listOf(id) + recent.filter { it != id }).take(50)
            prefs.edit().putString("recent", recent.joinToString(",")).apply()
        }
    }

    fun albumOf(t: Track): String = t.album.ifBlank { "Unknown Album" }
    fun hit(t: Track): Boolean = q.isEmpty() || (t.title + " " + t.artist + " " + t.album).contains(q, ignoreCase = true)
    fun sortSongs(l: List<Track>): List<Track> = when (sort) {
        1 -> l.sortedBy { it.title.lowercase() }
        2 -> l.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
        else -> l
    }

    val trackById = remember(tracks) { tracks.associateBy { it.id } }
    val visible = remember(tracks, hidden) { tracks.filter { it.id.toString() !in hidden } }
    val recentTracks = remember(recent, trackById) { recent.mapNotNull { trackById[it] } }
    val favTracks = remember(favs, tracks) { tracks.filter { it.id.toString() in favs } }

    val allSongs = remember(visible, q, sort) { sortSongs(visible.filter { hit(it) }) }
    val allRows = remember(allSongs) { allSongs.mapIndexed { i, t -> RowItem("s:" + t.id, t.title, t.artist, fmt(t.dur), 0, t.id.toString(), i) } }
    val artistRows = remember(visible, q) {
        visible.groupBy { it.artist }.entries
            .filter { q.isEmpty() || it.key.contains(q, ignoreCase = true) }
            .sortedBy { it.key.lowercase() }
            .map { RowItem("a:" + it.key, it.key, it.value.size.toString() + " songs", "", 1, it.key, 0) }
    }
    val albumRows = remember(visible, q) {
        visible.groupBy { albumOf(it) }.entries
            .filter { q.isEmpty() || it.key.contains(q, ignoreCase = true) }
            .sortedBy { it.key.lowercase() }
            .map { RowItem("b:" + it.key, it.key, it.value.first().artist + " - " + it.value.size + " songs", "", 2, it.key, 0) }
    }
    val plRows = remember(pls, recentTracks, favTracks, trackById) {
        val out = ArrayList<RowItem>()
        out.add(RowItem("new", "+ New playlist", "", "", 4, "", 0))
        out.add(RowItem("p:recent", "Recently Played", recentTracks.size.toString() + " songs", "", 3, "recent", 0))
        out.add(RowItem("p:fav", "Favourites", favTracks.size.toString() + " songs", "", 3, "fav", 0))
        pls.forEach { pl -> out.add(RowItem("p:" + pl.id, pl.name, pl.ids.count { trackById.containsKey(it) }.toString() + " songs", "", 3, pl.id, 0)) }
        out
    }
    val detailSongs = remember(detail, visible, favTracks, recentTracks, pls, trackById, q, sort) {
        val d = detail
        val base: List<Track> = when {
            d == null -> emptyList()
            d.startsWith("artist:") -> visible.filter { it.artist == d.removePrefix("artist:") }
            d.startsWith("album:") -> visible.filter { albumOf(it) == d.removePrefix("album:") }
            d == "pl:recent" -> recentTracks
            d == "pl:fav" -> favTracks
            else -> pls.firstOrNull { it.id == d.removePrefix("pl:") }?.ids?.mapNotNull { trackById[it] } ?: emptyList()
        }
        val f = base.filter { hit(it) }
        if (d != null && (d.startsWith("artist:") || d.startsWith("album:"))) sortSongs(f) else f
    }
    val detailRows = remember(detailSongs) { detailSongs.mapIndexed { i, t -> RowItem("s:" + t.id, t.title, t.artist, fmt(t.dur), 0, t.id.toString(), i) } }

    val cur = curId?.let { trackById[it] }
    BackHandler(enabled = detail != null && !showPlayer) { detail = null }
    BackHandler(enabled = showPlayer) { showPlayer = false }
    val total = if (durMs > 0) durMs else (cur?.dur ?: 0L)

    fun playFrom(list: List<Track>, i: Int) {
        val p = player ?: return
        p.setMediaItems(list.map { it.item() }, i, 0L); p.prepare(); p.play()
    }
    fun toggleFav(t: Track) {
        val k = t.id.toString()
        favs = if (k in favs) favs - k else favs + k
        prefs.edit().putStringSet("fav", favs).apply()
    }
    fun togglePlay() { val p = player ?: return; if (p.isPlaying) p.pause() else p.play() }
    fun savePls(l: List<Pl>) {
        pls = l
        val a = JSONArray()
        l.forEach { p -> a.put(JSONObject().put("id", p.id).put("name", p.name).put("ids", JSONArray(p.ids))) }
        prefs.edit().putString("pls", a.toString()).apply()
    }
    fun removeFromDetail(id: Long) {
        val d = detail ?: return
        when {
            d == "pl:fav" -> { favs = favs - id.toString(); prefs.edit().putStringSet("fav", favs).apply() }
            d == "pl:recent" -> { recent = recent.filter { it != id }; prefs.edit().putString("recent", recent.joinToString(",")).apply() }
            d.startsWith("pl:") -> { val pid = d.removePrefix("pl:"); savePls(pls.map { if (it.id == pid) it.copy(ids = it.ids - id) else it }) }
        }
    }
    fun inDetail(t: Track): Boolean {
        val d = detail ?: return false
        return if (d == "pl:fav") t.id.toString() in favs else (pls.firstOrNull { it.id == d.removePrefix("pl:") }?.ids?.contains(t.id) == true)
    }
    fun toggleInDetail(t: Track) {
        val d = detail ?: return
        if (d == "pl:fav") toggleFav(t) else {
            val pid = d.removePrefix("pl:")
            savePls(pls.map { if (it.id == pid) it.copy(ids = if (t.id in it.ids) it.ids - t.id else it.ids + t.id) else it })
        }
    }
    fun onRow(r: RowItem, songs: List<Track>) {
        when (r.kind) {
            0 -> playFrom(songs, r.idx)
            1 -> detail = "artist:" + r.arg
            2 -> detail = "album:" + r.arg
            3 -> detail = "pl:" + r.arg
            4 -> { pendingAdd = null; dlg = 1 }
        }
    }

    val dk = pal === DarkPal
    val scheme = if (dk) darkColorScheme(primary = Accent, surface = pal.card, onSurface = pal.tx, background = pal.bg, surfaceTint = Color.Transparent)
        else lightColorScheme(primary = Accent, surface = pal.card, onSurface = pal.tx, background = pal.bg, surfaceTint = Color.Transparent)

    MaterialTheme(colorScheme = scheme, shapes = Shapes(extraSmall = RoundedCornerShape(16.dp))) {
    CompositionLocalProvider(LocalPal provides pal) {
        Box(Modifier.fillMaxSize().background(pal.bg)) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 10.dp, top = 10.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Library", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = pal.tx, modifier = Modifier.weight(1f))
                }
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().height(46.dp).clip(RoundedCornerShape(14.dp)).background(pal.fill).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Search, null, tint = pal.tx2, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Search", color = pal.tx2, fontSize = 17.sp)
                        BasicTextField(query, { query = it }, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 17.sp), cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
                    }
                }
                TabChips(pager, detail == null, sort, { sort = (sort + 1) % 3 }) { i -> detail = null; pagerScope.launch { pager.animateScrollToPage(i) } }
                val d = detail
                if (d != null) {
                    val title = when {
                        d.startsWith("artist:") -> d.removePrefix("artist:")
                        d.startsWith("album:") -> d.removePrefix("album:")
                        d == "pl:recent" -> "Recently Played"
                        d == "pl:fav" -> "Favourites"
                        else -> pls.firstOrNull { it.id == d.removePrefix("pl:") }?.name ?: "Playlist"
                    }
                    val canAdd = d == "pl:fav" || (d.startsWith("pl:") && d != "pl:recent")
                    val userPl = d.startsWith("pl:") && d != "pl:recent" && d != "pl:fav"
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(Icons.Rounded.ArrowBackIosNew, Accent, box = 40.dp, size = 20.dp) { detail = null }
                        Column(Modifier.weight(1f)) {
                            Text(title, color = pal.tx, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(detailSongs.size.toString() + " songs", color = pal.tx2, fontSize = 13.sp)
                        }
                        if (canAdd) Text("Add songs", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { dlg = 3 }.padding(horizontal = 10.dp, vertical = 8.dp))
                        if (userPl) Text("Delete", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { val pid = d.removePrefix("pl:"); detail = null; savePls(pls.filter { it.id != pid }) }.padding(horizontal = 10.dp, vertical = 8.dp))
                    }
                } else {
                    CountRow(pager, allSongs.size, artistRows.size, albumRows.size, hidden.size) { hidden = emptySet(); prefs.edit().putStringSet("hidden", hidden).apply() }
                }
                if (!granted) {
                    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tunes needs access to your music to build your library. Grant it in Settings, then come back to the app.", color = pal.tx2, fontSize = 15.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Open Settings") }
                    }
                } else if (d != null) {
                    RowsList(
                        detailRows, detailState, curId, cur != null,
                        if (d.startsWith("pl:")) "Empty. Tap Add songs to fill it." else "No songs",
                        d.startsWith("pl:"),
                        { listH = it },
                        { r -> onRow(r, detailSongs) },
                        { r -> removeFromDetail(r.arg.toLong()) }
                    )
                } else {
                    HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), beyondBoundsPageCount = 1) { page ->
                        val rows = when (page) { 0 -> allRows; 1 -> artistRows; 2 -> albumRows; else -> plRows }
                        RowsList(
                            rows, listStates[page], curId, cur != null,
                            when (page) { 0 -> "No songs found"; 1 -> "No artists"; 2 -> "No albums"; else -> "" },
                            false,
                            { listH = it },
                            { r -> onRow(r, allSongs) },
                            { }
                        )
                    }
                }
            }

            if (cur != null) {
                val scrim = if (dk) Color.Black.copy(alpha = .6f) else Color.White.copy(alpha = .7f)
                Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().clipToBounds().clickable { showPlayer = true }) {
                    MiniGhost(Modifier.matchParentSize(), pager, detail != null, listOf(allRows, artistRows, albumRows, plRows), detailRows, listStates, detailState, listH)
                    Box(Modifier.matchParentSize().background(scrim))
                    Column {
                        MiniBar(ps, total, Modifier)
                        Row(Modifier.fillMaxWidth().clickable { showPlayer = true }.navigationBarsPadding().padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Cover(cur, Modifier.size(54.dp), 8.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(cur.title, color = pal.tx, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false, modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE))
                                Text(cur.artist, color = pal.tx2, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconBtn(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, box = 52.dp, size = 32.dp) { togglePlay() }
                            IconBtn(Icons.Rounded.SkipNext, box = 52.dp, size = 32.dp) { player?.seekToNext() }
                        }
                    }
                }
            }

            if (dlg == 1) {
                var name by remember { mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { dlg = 0; pendingAdd = null },
                    containerColor = pal.card,
                    title = { Text("New playlist", color = pal.tx) },
                    text = {
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.fill).padding(12.dp)) {
                            if (name.isEmpty()) Text("Name", color = pal.tx2, fontSize = 17.sp)
                            BasicTextField(name, { name = it }, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 17.sp), cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val n = name.trim()
                            if (n.isNotEmpty()) {
                                val first = pendingAdd
                                val pl = Pl(System.currentTimeMillis().toString(), n, if (first != null) listOf(first.id) else emptyList())
                                savePls(pls + pl)
                                if (first == null) { detail = "pl:" + pl.id }
                            }
                            dlg = 0; pendingAdd = null
                        }) { Text("Create", color = Accent) }
                    },
                    dismissButton = { TextButton(onClick = { dlg = 0; pendingAdd = null }) { Text("Cancel", color = pal.tx2) } }
                )
            }
            if (dlg == 2 && cur != null) {
                AlertDialog(
                    onDismissRequest = { dlg = 0 },
                    containerColor = pal.card,
                    title = { Text("Add to playlist", color = pal.tx) },
                    text = {
                        Column {
                            pls.forEach { pl ->
                                val has = cur.id in pl.ids
                                Row(Modifier.fillMaxWidth().clickable {
                                    savePls(pls.map { if (it.id == pl.id) it.copy(ids = if (has) it.ids - cur.id else it.ids + cur.id) else it })
                                }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(pl.name, color = pal.tx, fontSize = 16.sp, modifier = Modifier.weight(1f))
                                    if (has) Icon(Icons.Rounded.Check, null, tint = Accent)
                                }
                            }
                            Text("New playlist...", color = Accent, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { pendingAdd = cur; dlg = 1 }.padding(vertical = 12.dp))
                        }
                    },
                    confirmButton = { TextButton(onClick = { dlg = 0 }) { Text("Done", color = Accent) } }
                )
            }
            if (dlg == 3) {
                var pq by remember { mutableStateOf("") }
                val cand = remember(visible, pq) { visible.filter { pq.isBlank() || (it.title + " " + it.artist).contains(pq, ignoreCase = true) } }
                AlertDialog(
                    onDismissRequest = { dlg = 0 },
                    containerColor = pal.card,
                    title = { Text("Add songs", color = pal.tx) },
                    text = {
                        Column {
                            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.fill).padding(10.dp)) {
                                if (pq.isEmpty()) Text("Search", color = pal.tx2, fontSize = 16.sp)
                                BasicTextField(pq, { pq = it }, singleLine = true, textStyle = TextStyle(color = pal.tx, fontSize = 16.sp), cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
                            }
                            Spacer(Modifier.height(8.dp))
                            LazyColumn(Modifier.fillMaxWidth().height(360.dp)) {
                                items(cand, key = { it.id }) { t ->
                                    val has = inDetail(t)
                                    Row(Modifier.fillMaxWidth().clickable { toggleInDetail(t) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(t.title, color = pal.tx, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(t.artist, color = pal.tx2, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        if (has) Icon(Icons.Rounded.Check, null, tint = Accent)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { dlg = 0 }) { Text("Done", color = Accent) } }
                )
            }

            val c = cur
            if (c != null) {
                AnimatedVisibility(visible = showPlayer, enter = slideInVertically(tween(320)) { it }, exit = slideOutVertically(tween(260)) { it }) {
                    val base = coverColor(c)
                    val bgc = if (dk) Color(0xFF0B0B14) else Color(0xFFF7F7FB)
                    val fg = if (dk) Color.White else Color(0xFF111114)
                    val fg2 = fg.copy(alpha = .6f)
                    val brush = Brush.verticalGradient(
                        listOf(
                            lerp(bgc, base, if (dk) .22f else .18f),
                            lerp(bgc, base, if (dk) .45f else .32f),
                            lerp(bgc, base, if (dk) .18f else .14f)
                        )
                    )
                    var menu by remember { mutableStateOf(false) }
                    var queueMenu by remember { mutableStateOf(false) }
                    val menuBg = lerp(bgc, base, if (dk) .5f else .35f)
                    val menuScheme = scheme.copy(surface = menuBg, onSurface = fg)
                    val menuShapes = Shapes(extraSmall = RoundedCornerShape(18.dp))
                    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
                    val maxV = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
                    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV) }
                    var volDrag by remember { mutableStateOf(false) }
                    LaunchedEffect(Unit) {
                        while (true) { if (!volDrag) vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV; delay(500) }
                    }
                    val fav = c.id.toString() in favs
                    val cfg = LocalConfiguration.current
                    // Size artwork against usable height so system bars do not push controls off-screen.
                    val usablePlayerHeight = (cfg.screenHeightDp - 96).coerceAtLeast(420).dp
                    val coverSize = minOf(cfg.screenWidthDp.dp - 40.dp, usablePlayerHeight * 0.32f)
                    val inLists = remember(pls, favs, c) {
                        val out = ArrayList<String>()
                        if (c.id.toString() in favs) out.add("Favourites")
                        pls.filter { c.id in it.ids }.forEach { out.add(it.name) }
                        out
                    }
                    val upNext = remember(qv, curId, shuffle, player, trackById) {
                        val out = ArrayList<Pair<Int, Track>>()
                        val p = player
                        if (p != null) {
                            val tl = p.currentTimeline
                            if (!tl.isEmpty) {
                                var idx = p.currentMediaItemIndex
                                var n = 0
                                while (n < 40) {
                                    idx = tl.getNextWindowIndex(idx, Player.REPEAT_MODE_OFF, p.shuffleModeEnabled)
                                    if (idx == C.INDEX_UNSET) break
                                    val t = p.getMediaItemAt(idx).mediaId.toLongOrNull()?.let { trackById[it] }
                                    if (t != null) out.add(Pair(idx, t))
                                    n++
                                }
                            }
                        }
                        out
                    }
                    val dragY = remember { Animatable(0f) }
                    val dragScope = rememberCoroutineScope()
                    val closePx = with(LocalDensity.current) { 140.dp.toPx() }
                    val dragState = rememberDraggableState { dy -> dragScope.launch { dragY.snapTo((dragY.value + dy).coerceAtLeast(0f)) } }
                    val pullDown = Modifier.draggable(
                        state = dragState,
                        orientation = Orientation.Vertical,
                        onDragStopped = { v ->
                            if (dragY.value > closePx || v > 1200f) {
                                showPlayer = false
                            } else {
                                dragY.animateTo(0f, spring(stiffness = Spring.StiffnessMediumLow))
                            }
                        }
                    )
                    Column(Modifier.fillMaxSize().offset { IntOffset(0, dragY.value.roundToInt()) }.background(brush).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}.statusBarsPadding().navigationBarsPadding()) {
                        Box(Modifier.fillMaxWidth().height(48.dp).then(pullDown), contentAlignment = Alignment.Center) {
                            Box(Modifier.clip(RoundedCornerShape(12.dp)).clickable { showPlayer = false }.padding(horizontal = 24.dp, vertical = 14.dp)) { Box(Modifier.width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(fg2.copy(alpha = .5f))) }
                        }
                        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                            Box(Modifier.fillMaxWidth().then(pullDown), contentAlignment = Alignment.Center) {
                                Cover(c, Modifier.size(coverSize).shadow(24.dp, RoundedCornerShape(22.dp)), 22.dp, big = true)
                            }
                            Column(Modifier.padding(horizontal = 24.dp)) {
                                Spacer(Modifier.height(10.dp))
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(c.title, color = fg, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(c.artist, color = fg2, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Box {
                                        Box(Modifier.size(38.dp).clip(CircleShape).background(fg.copy(alpha = .18f)).clickable { menu = true }, contentAlignment = Alignment.Center) {
                                            Icon(Icons.Rounded.MoreHoriz, null, tint = fg, modifier = Modifier.size(22.dp))
                                        }
                                        MaterialTheme(colorScheme = menuScheme, shapes = menuShapes) {
                                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                                Row(
                                                    Modifier.fillMaxWidth().clickable {
                                                        menu = false; showPlayer = false
                                                        pagerScope.launch { pager.scrollToPage(1) }
                                                        detail = "artist:" + c.artist
                                                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(Modifier.weight(1f)) {
                                                        Text("Artist", color = fg2, fontSize = 12.sp)
                                                        Text(c.artist, color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                                    }
                                                    Icon(Icons.Rounded.ChevronRight, null, tint = fg2, modifier = Modifier.size(20.dp))
                                                }
                                                Row(
                                                    Modifier.fillMaxWidth().clickable {
                                                        menu = false; showPlayer = false
                                                        pagerScope.launch { pager.scrollToPage(2) }
                                                        detail = "album:" + albumOf(c)
                                                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(Modifier.weight(1f)) {
                                                        Text("Album", color = fg2, fontSize = 12.sp)
                                                        Text(albumOf(c), color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                                    }
                                                    Icon(Icons.Rounded.ChevronRight, null, tint = fg2, modifier = Modifier.size(20.dp))
                                                }
                                                Box(Modifier.fillMaxWidth().height(1.dp).background(fg.copy(alpha = .12f)))
                                                DropdownMenuItem(
                                                    text = { Text("Playlist", color = fg) },
                                                    leadingIcon = { Icon(Icons.Rounded.PlaylistAdd, null, tint = fg2) },
                                                    onClick = { menu = false; dlg = 2 }
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                PlayerSeek(ps, total, fg, { dragging = true }, { v -> player?.seekTo(v); dragging = false })
                                Spacer(Modifier.height(6.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    IconBtn(Icons.Rounded.Shuffle, if (shuffle) fg else fg2) { player?.shuffleModeEnabled = !shuffle }
                                    IconBtn(Icons.Rounded.FastRewind, fg, box = 64.dp, size = 46.dp) { player?.seekToPrevious() }
                                    IconBtn(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, fg, box = 84.dp, size = 62.dp) { togglePlay() }
                                    IconBtn(Icons.Rounded.FastForward, fg, box = 64.dp, size = 46.dp) { player?.seekToNext() }
                                    IconBtn(if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, if (repeat == Player.REPEAT_MODE_OFF) fg2 else fg) {
                                        player?.repeatMode = when (repeat) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.VolumeDown, null, tint = fg2, modifier = Modifier.size(22.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Box(Modifier.weight(1f)) {
                                        Bar(vol, fg, false, { f -> volDrag = true; vol = f; am.setStreamVolume(AudioManager.STREAM_MUSIC, (f * maxV).roundToInt(), 0) }, { volDrag = false })
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Icon(Icons.Rounded.VolumeUp, null, tint = fg2, modifier = Modifier.size(22.dp))
                                }
                                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    IconBtn(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (fav) Accent else fg2) { toggleFav(c) }
                                    Box {
                                        IconBtn(Icons.Rounded.Menu, fg2) { queueMenu = true }
                                        MaterialTheme(colorScheme = menuScheme, shapes = menuShapes) {
                                            DropdownMenu(expanded = queueMenu, onDismissRequest = { queueMenu = false }, modifier = Modifier.width(300.dp).heightIn(max = 440.dp)) {
                                                Text("Up next", color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                                                if (upNext.isEmpty()) {
                                                    Text("Nothing queued", color = fg2, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                                                }
                                                upNext.forEach { pr ->
                                                    Row(
                                                        Modifier.fillMaxWidth().clickable { player?.seekToDefaultPosition(pr.first); player?.play(); queueMenu = false }.padding(horizontal = 16.dp, vertical = 10.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(Modifier.weight(1f)) {
                                                            Text(pr.second.title, color = fg, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                            Text(pr.second.artist, color = fg2, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                        }
                                                        Spacer(Modifier.width(10.dp))
                                                        Text(fmt(pr.second.dur), color = fg2, fontSize = 13.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (inLists.isNotEmpty()) {
                                    Spacer(Modifier.height(16.dp))
                                    Text("In playlists", color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        inLists.forEach { name ->
                                            Box(Modifier.clip(RoundedCornerShape(16.dp)).background(fg.copy(alpha = .14f)).clickable { dlg = 2 }.padding(horizontal = 14.dp, vertical = 8.dp)) {
                                                Text(name, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(24.dp))
                            }
                        }
                    }
                }
            }
        }
    }
    }
}
