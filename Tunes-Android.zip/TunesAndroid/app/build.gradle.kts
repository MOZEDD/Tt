plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
val runNo = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toIntOrNull() ?: 1   // grows with every CI build so updates install over the old app
android {
    namespace = "com.tunes.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.tunes.app"; minSdk = 26; targetSdk = 34; versionCode = runNo; versionName = "1.0.4" }
    signingConfigs { create("tunes") { storeFile = file("tunes.keystore"); storePassword = "tunes123"; keyAlias = "tunes"; keyPassword = "tunes123" } }
    buildTypes { release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"); signingConfig = signingConfigs.getByName("tunes") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")
}
