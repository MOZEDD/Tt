# Tunes (native Android)
Kotlin + Jetpack Compose + Media3. Themes > Style has two swatches: Classic and Glossy (Liquid Glass-style floating mini player, segmented glass tabs, capsule search, iOS system colors). Plays music already on your phone, shows embedded cover art, plays in the background with a media notification.

## Build the APK
**Android Studio:** File > Open this folder > Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk

**GitHub:** push this folder to a repo (branch `main`). Actions > "Build APK" runs automatically; download `Tunes-APK` from the run's Artifacts.
